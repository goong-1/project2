import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from sensor_msgs.msg import Imu
from geometry_msgs.msg import Twist
import math

class VirtualESP32(Node):
    def __init__(self):
        super().__init__('virtual_esp32')
        
        # Pub/Sub 설정
        self.cmd_sub = self.create_subscription(String, '/esp_command', self.cmd_callback, 10)
        self.imu_sub = self.create_subscription(Imu, '/imu', self.imu_callback, 10)
        self.status_pub = self.create_publisher(String, '/esp_status', 10)
        self.vel_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        
        self.timer = self.create_timer(0.01, self.control_loop)

        # 상태 변수
        self.state = 'STOP'
        self.current_yaw = 0.0
        self.target_yaw = 0.0
        self.target_speed = 0.0

        # ★ [추가 이식] PC의 중복 타이머 전송(Heartbeat)에 의한 타겟 누적 방지용 변수
        self.active_turn_cmd = ""

        # PID 제어 변수
        self.kp_turn = 10.0
        self.ki_turn = 0.0
        self.kd_turn = 0.1
        self.prev_error = 0.0
        self.integral = 0.0

        self.get_logger().info("Virtual ESP32 Node Started (Clean Executor Mode).")

    def imu_callback(self, msg):
        q = msg.orientation
        siny_cosp = 2 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z)
        self.current_yaw = math.atan2(siny_cosp, cosy_cosp)

    def publish_done(self):
        msg = String()
        msg.data = "DONE"
        self.status_pub.publish(msg)
        self.get_logger().info("Sent status: DONE")

    def cmd_callback(self, msg):
        cmd_str = msg.data.strip().upper()
        if not cmd_str: return

        command = cmd_str[0]
        value = float(cmd_str[1:]) if len(cmd_str) > 1 else 0.0

        if command == 'S':
            self.state = 'STOP'
            self.active_turn_cmd = "" # 정지 시 현재 회전 명령 초기화
            self.publish_done()
        elif command == 'G':
            self.state = 'DRIVE'
            self.active_turn_cmd = "" # 주행 시작 시 회전 명령 초기화
            self.target_speed = (value / 255.0) * 1.5
        elif command == 'T':
            # ★ [방어 로직 이식] 현재 이미 회전 중이고, 새로 들어온 회전 명령이 기존과 같다면 패스!
            if self.state == 'TURN' and self.active_turn_cmd == cmd_str:
                return 

            self.state = 'TURN'
            self.active_turn_cmd = cmd_str # 새로운 회전 명령 저장
            target_offset_rad = math.radians(value)
            self.target_yaw = self.normalize_angle(self.current_yaw + target_offset_rad)
            self.prev_error = 0.0
            self.integral = 0.0

    def normalize_angle(self, angle):
        while angle > math.pi: angle -= 2.0 * math.pi
        while angle < -math.pi: angle += 2.0 * math.pi
        return angle

    def control_loop(self):
        twist = Twist()

        if self.state == 'DRIVE':
            twist.linear.x = self.target_speed
        elif self.state == 'TURN':
            error = self.normalize_angle(self.target_yaw - self.current_yaw)
            if abs(error) < 0.026:
                self.state = 'STOP'
                self.active_turn_cmd = "" # ★ [추가 이식] 회전 완료 시 저장된 명령 리셋
                self.publish_done()
            else:
                self.integral += error * 0.01
                derivative = (error - self.prev_error) / 0.01
                control_signal = (self.kp_turn * error) + (self.ki_turn * self.integral) + (self.kd_turn * derivative)
                twist.angular.z = max(min(control_signal, 8.0), -8.0)
                self.prev_error = error
        
        self.vel_pub.publish(twist)

def main(args=None):
    rclpy.init(args=args)
    node = VirtualESP32()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
    
if __name__ == '__main__':
    main()
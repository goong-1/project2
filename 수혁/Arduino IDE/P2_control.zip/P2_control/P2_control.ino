#include <Arduino.h>
#include <cmath>
#include "IMU.h"
#include "soc/soc.h"
#include "soc/rtc_cntl_reg.h"

// [핀 맵 설정]
const uint16_t PWMA = 26; const uint16_t AIN1 = 22; const uint16_t AIN2 = 23;
const uint16_t PWMB = 25; const uint16_t BIN1 = 21; const uint16_t BIN2 = 17;
const uint16_t AENCA = 35; const uint16_t AENCB = 34;
const uint16_t BENCA = 27; const uint16_t BENCB = 16;

volatile long A_wheel_pulse_count = 0;
volatile long B_wheel_pulse_count = 0;
volatile int current_dir_A = 1;
volatile int current_dir_B = 1;
void IRAM_ATTR A_wheel_pulse() { A_wheel_pulse_count += current_dir_A; }
void IRAM_ATTR B_wheel_pulse() { B_wheel_pulse_count += current_dir_B; }

// [물리 가중치 및 제어 게인 설정]
const float MOTOR_A_WEIGHT = 1.01;
const float MOTOR_B_WEIGHT = 1.00;
const float HEADING_KP = 1.2;
const int TURN_SPEED = 85;

// [제어 상태 및 센서 변수]
enum RobotState { IDLE, DRIVE_STRAIGHT, TURN };
RobotState currentState = IDLE;

EulerAngles stAngles;
IMU_ST_SENSOR_DATA_FLOAT stGyroRawData, stAccelRawData;
IMU_ST_SENSOR_DATA stMagnRawData;

float target_yaw = 0.0;
float current_yaw = 0.0;
float gyro_z_offset = 0.0;
float gyro_accumulated_deg = 0.0;
float target_turn_angle = 0.0;

int current_speed = 0; 
String cmd_buffer = "";
String last_cmd = "";

unsigned long last_communication_time = 0;
const unsigned long SAFETY_TIMEOUT_MS = 2000; 

void controlMotor(char motor, int speed) {
  uint16_t pwm_pin, in1_pin, in2_pin;
  float weight = 1.0;
  if (motor == 'A') {
    pwm_pin = PWMA; in1_pin = AIN1; in2_pin = AIN2; weight = MOTOR_A_WEIGHT;
  } else {
    pwm_pin = PWMB; in1_pin = BIN1; in2_pin = BIN2; weight = MOTOR_B_WEIGHT;
  }

  int final_speed = constrain((int)(speed * weight), -255, 255);

  if (final_speed > 0) {
    digitalWrite(in1_pin, LOW); digitalWrite(in2_pin, HIGH);
    ledcWrite(pwm_pin, final_speed);
  } else if (final_speed < 0) {
    digitalWrite(in1_pin, HIGH); digitalWrite(in2_pin, LOW);
    ledcWrite(pwm_pin, abs(final_speed));
  } else {
    digitalWrite(in1_pin, HIGH); digitalWrite(in2_pin, HIGH);
    ledcWrite(pwm_pin, 0);
  }
}

void calibrateGyro() {
  float sum = 0;
  int samples = 500;
  for (int i = 0; i < samples; i++) {
    imuDataGet(&stAngles, &stGyroRawData, &stAccelRawData, &stMagnRawData);
    sum += stGyroRawData.Z;
    delay(2);
  }
  gyro_z_offset = sum / samples;
}

void setup() {
  WRITE_PERI_REG(RTC_CNTL_BROWN_OUT_REG, 0); 
  Serial.begin(115200); 
  delay(1000);
  
  pinMode(AIN1, OUTPUT); pinMode(AIN2, OUTPUT);
  pinMode(BIN1, OUTPUT); pinMode(BIN2, OUTPUT);
  pinMode(AENCA, INPUT); pinMode(AENCB, INPUT);
  pinMode(BENCA, INPUT); pinMode(BENCB, INPUT);
  attachInterrupt(digitalPinToInterrupt(AENCA), A_wheel_pulse, RISING);
  attachInterrupt(digitalPinToInterrupt(BENCA), B_wheel_pulse, RISING);
  ledcAttach(PWMA, 20000, 8);
  ledcAttach(PWMB, 20000, 8);
  
  imuInit();
  delay(500);
  calibrateGyro();
  last_communication_time = millis();
}

void loop() {
  static unsigned long last_loop_time = 0;
  unsigned long now = micros();
  if (last_loop_time == 0) last_loop_time = now;
  float dt = (now - last_loop_time) / 1000000.0;
  last_loop_time = now;

  imuDataGet(&stAngles, &stGyroRawData, &stAccelRawData, &stMagnRawData);
  float gyro_z_deg_per_sec = (stGyroRawData.Z - gyro_z_offset);

  // 1. 명령어 패킷 스트림 분석
  while (Serial.available() > 0) {
    char c = Serial.read();
    last_communication_time = millis();

    if (c == '<') {
      cmd_buffer = "";
    } else if (c == '>') {
      if (cmd_buffer != last_cmd) { 
        if (cmd_buffer == "s") {
          currentState = IDLE;
          controlMotor('A', 0); controlMotor('B', 0);
          last_cmd = cmd_buffer;
          Serial.println("DONE"); // 💡 정지 즉시 완료 신호 1회 발행
        } 
        else if (cmd_buffer.startsWith("g,")) {
          current_speed = cmd_buffer.substring(2).toInt();
          target_yaw = current_yaw; 
          currentState = DRIVE_STRAIGHT;
          last_cmd = cmd_buffer;
          // 💡 직진 명령은 지속적으로 제어 루프를 돌아야 하므로 DONE을 여기서 쏘지 않습니다!
        } 
        else if (cmd_buffer.startsWith("t,")) {
          target_turn_angle = cmd_buffer.substring(2).toFloat();
          gyro_accumulated_deg = 0.0; 
          currentState = TURN;
          last_cmd = cmd_buffer;
        }
      }
      cmd_buffer = "";
    } else {
      cmd_buffer += c;
    }
  }

  // 2. 통신 두절 세이프가드
  if (millis() - last_communication_time > SAFETY_TIMEOUT_MS) {
    if (currentState != IDLE) {
      controlMotor('A', 0); controlMotor('B', 0);
      currentState = IDLE;
      last_cmd = ""; 
    }
  }

  // 3. 주행 상태 머신
  if (currentState == DRIVE_STRAIGHT) {
    current_yaw += (gyro_z_deg_per_sec * dt);
    float error = target_yaw - current_yaw;
    while (error > 180.0) error -= 360.0;
    while (error <= -180.0) error += 360.0;

    int correction = constrain((int)(error * HEADING_KP), -40, 40);
    int speed_A = constrain(current_speed + correction, 0, 255);
    int speed_B = constrain(current_speed - correction, 0, 255);
    
    controlMotor('A', speed_A); controlMotor('B', speed_B);
  } 
  else if (currentState == TURN) {
    if (abs(gyro_z_deg_per_sec) > 0.1) {
      gyro_accumulated_deg += (gyro_z_deg_per_sec * dt);
    }
    
    if (abs(gyro_accumulated_deg) >= abs(target_turn_angle)) {
      controlMotor('A', 0); controlMotor('B', 0);
      currentState = IDLE;
      last_cmd = "s"; 
      Serial.println("DONE"); // 💡 회전 목표 각도 도달 완료 신호 딱 1회 발행!
    } else {
      if (target_turn_angle > 0) { 
        controlMotor('A', -TURN_SPEED); controlMotor('B', TURN_SPEED);
      } else { 
        controlMotor('A', TURN_SPEED);  controlMotor('B', -TURN_SPEED);
      }
    }
  }

  // 4. 상태 피드백 전송 (파이썬에서 단순 텔레메트리로 인지하도록 구분자 추가)
  static unsigned long last_send_time = 0;
  if (millis() - last_send_time >= 50) {
    last_send_time = millis();
    Serial.print("[TELEMETRY] MODE: ");
    if(currentState == IDLE) Serial.print("IDLE");
    else if(currentState == DRIVE_STRAIGHT) Serial.print("DRIVE");
    else if(currentState == TURN) Serial.print("TURN");
    Serial.print(" | Yaw: "); Serial.print(current_yaw);
    Serial.print(" | TurnAng: "); Serial.println(gyro_accumulated_deg);
  }
  delay(1); 
}
#include <Arduino.h>
#include <WiFi.h>
#include <cmath>
#include "IMU.h"
#include "soc/soc.h"
#include "soc/rtc_cntl_reg.h"

// ==========================================
// [네트워크 고정 IP 및 서버 설정]
// ==========================================
const char* ssid = "asia-edu_2G";
const char* password = "12345678";

IPAddress local_IP(192, 168, 0, 9);
IPAddress gateway(192, 168, 0, 1);
IPAddress subnet(255, 255, 255, 0);

WiFiServer server(8080);
WiFiClient client;

// ==========================================
// [핀 맵 설정]
// ==========================================
const uint16_t PWMA = 26; const uint16_t AIN1 = 22; const uint16_t AIN2 = 23;
const uint16_t PWMB = 25; const uint16_t BIN1 = 21; const uint16_t BIN2 = 17;
const uint16_t AENCA = 35; const uint16_t AENCB = 34;
const uint16_t BENCA = 27; const uint16_t BENCB = 16;

// ==========================================
// [엔코더 카운트 전역 변수]
// ==========================================
volatile long A_wheel_pulse_count = 0;
volatile long B_wheel_pulse_count = 0;
volatile int current_dir_A = 1;
volatile int current_dir_B = 1;

void IRAM_ATTR A_wheel_pulse() { A_wheel_pulse_count += current_dir_A; }
void IRAM_ATTR B_wheel_pulse() { B_wheel_pulse_count += current_dir_B; }

// ==========================================
// [물리 가중치 및 제어 게인 설정]
// ==========================================
const float MOTOR_A_WEIGHT = 1.01;
const float MOTOR_B_WEIGHT = 1.00;
const float HEADING_KP = 1.2;
const int TURN_SPEED = 85;

// ==========================================
// [제어 상태 및 센서 변수]
// ==========================================
enum RobotState { IDLE, DRIVE_STRAIGHT, TURN };
RobotState currentState = IDLE;

EulerAngles stAngles;
IMU_ST_SENSOR_DATA_FLOAT stGyroRawData, stAccelRawData;
IMU_ST_SENSOR_DATA stMagnRawData;

float target_yaw = 0.0;
float current_yaw = 0.0;
float gyro_z_offset = 0.0;
float gyro_accumulated_deg = 0.0;
float target_turn_angle = 0.0;

int current_speed = 0; // 라즈베리파이로부터 명령받은 가변 주행 속도 저장
String cmd_buffer = "";

// 통신 차단 안전 감시용 타임스탬프
unsigned long last_communication_time = 0;
const unsigned long SAFETY_TIMEOUT_MS = 2000; // 통신 두절 허용 시간 (2초)

// ==========================================
// [모터 액추에이팅 제어 함수]
// ==========================================
void controlMotor(char motor, int speed) {
  uint16_t pwm_pin, in1_pin, in2_pin;
  float weight = 1.0;
  if (motor == 'A') {
    pwm_pin = PWMA; in1_pin = AIN1; in2_pin = AIN2; weight = MOTOR_A_WEIGHT;
  } else {
    pwm_pin = PWMB; in1_pin = BIN1; in2_pin = BIN2; weight = MOTOR_B_WEIGHT;
  }

  int final_speed = constrain((int)(speed * weight), -255, 255);

  if (final_speed > 0) {
    digitalWrite(in1_pin, HIGH); digitalWrite(in2_pin, LOW);
    ledcWrite(pwm_pin, final_speed);
  } else if (final_speed < 0) {
    digitalWrite(in1_pin, LOW); digitalWrite(in2_pin, HIGH);
    ledcWrite(pwm_pin, abs(final_speed));
  } else {
    digitalWrite(in1_pin, LOW); digitalWrite(in2_pin, LOW);
    ledcWrite(pwm_pin, 0);
  }
}

// ==========================================
// [자이로스코프 영점 교정]
// ==========================================
void calibrateGyro() {
  float sum = 0;
  int samples = 500;
  for (int i = 0; i < samples; i++) {
    imuDataGet(&stAngles, &stGyroRawData, &stAccelRawData, &stMagnRawData);
    sum += stGyroRawData.Z;
    delay(2);
  }
  gyro_z_offset = sum / samples;
}

// ==========================================
// [초기 설정]
// ==========================================
void setup() {
  WRITE_PERI_REG(RTC_CNTL_BROWN_OUT_REG, 0); // 브라운아웃 리셋 방지
  Serial.begin(115200);

  pinMode(AIN1, OUTPUT); pinMode(AIN2, OUTPUT);
  pinMode(BIN1, OUTPUT); pinMode(BIN2, OUTPUT);
  pinMode(AENCA, INPUT); pinMode(AENCB, INPUT);
  pinMode(BENCA, INPUT); pinMode(BENCB, INPUT);
  attachInterrupt(digitalPinToInterrupt(AENCA), A_wheel_pulse, RISING);
  attachInterrupt(digitalPinToInterrupt(BENCA), B_wheel_pulse, RISING);

  ledcAttach(PWMA, 20000, 8);
  ledcAttach(PWMB, 20000, 8);
  
  imuInit();
  delay(500);
  calibrateGyro();

  if (!WiFi.config(local_IP, gateway, subnet)) {
    Serial.println("고정 IP 설정 실패");
  }

  WiFi.begin(ssid, password);
  Serial.print("Wi-Fi 연결 중");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWi-Fi 연결 완료");
  Serial.print("로봇 접속 대기 고정 IP 주소: ");
  Serial.println(WiFi.localIP());

  server.begin();
  last_communication_time = millis();
}

// ==========================================
// [메인 제어 루프]
// ==========================================
void loop() {
  // 1. 비차단 방식으로 라즈베리파이 소켓 접속 확인 및 유지
  if (!client || !client.connected()) {
    WiFiClient new_client = server.available();
    if (new_client) {
      client = new_client;
      Serial.println("라즈베리파이 상위 노드 무선 세션 접속 성공!");
      cmd_buffer = "";
      last_communication_time = millis(); // 접속 시점 타임스탬프 갱신
    }
  }

  // 자이로 누적 적분을 위한 마이크로초 기반 정밀 시간 변화량 계산
  static unsigned long last_loop_time = 0;
  unsigned long now = micros();
  if (last_loop_time == 0) last_loop_time = now;
  float dt = (now - last_loop_time) / 1000000.0;
  last_loop_time = now;

  imuDataGet(&stAngles, &stGyroRawData, &stAccelRawData, &stMagnRawData);
  float gyro_z_deg_per_sec = (stGyroRawData.Z - gyro_z_offset);

  // 2. 명령어 패킷 스트림 순차 분석 및 파싱
  if (client && client.connected()) {
    while (client.available() > 0) {
      char c = client.read();
      last_communication_time = millis(); // 패킷 데이터가 들어오는 매 순간 시간 동기화

      if (c == '<') {
        cmd_buffer = "";
      } else if (c == '>') {
        // [명령 1] 즉시 정지 명령
        if (cmd_buffer == "s") {
          currentState = IDLE;
          controlMotor('A', 0); controlMotor('B', 0);
          Serial.println(">> [ACK] STOP RECEIVED");
        } 
        // [명령 2] 가변 속도 직진 명령 (예: <g,150>)
        else if (cmd_buffer.startsWith("g,")) {
          current_speed = cmd_buffer.substring(2).toInt();
          target_yaw = current_yaw; // 명령어가 하사된 시점의 방위 기수를 목표 각도로 락온
          currentState = DRIVE_STRAIGHT;
          Serial.print(">> [ACK] DRIVE STRAIGHT WITH SPEED: "); Serial.println(current_speed);
        } 
        // [명령 3] 정밀 회전 명령 (예: <t,-90>)
        else if (cmd_buffer.startsWith("t,")) {
          target_turn_angle = cmd_buffer.substring(2).toFloat();
          gyro_accumulated_deg = 0.0; // 회전 시작 전 상대 적분 각도 초기화
          currentState = TURN;
          Serial.print(">> [ACK] TURN DEGREE: "); Serial.println(target_turn_angle);
        }
        cmd_buffer = "";
      } else {
        cmd_buffer += c;
      }
    }
  }

  // 3. 락오프 세이프가드 가동 (라즈베리파이와 연결이 장시간 끊어졌을 때)
  if (millis() - last_communication_time > SAFETY_TIMEOUT_MS) {
    if (currentState != IDLE) {
      controlMotor('A', 0); controlMotor('B', 0);
      currentState = IDLE;
      Serial.println("🚨 [WARNING] 상위 노드 통신 두절로 인한 긴급 제동 및 대기 전환!");
    }
  }

  // 4. 주행 상태 머신 및 실시간 액추에이팅 보정
  if (currentState == DRIVE_STRAIGHT) {
    current_yaw += (gyro_z_deg_per_sec * dt); // 상시 로봇 방위각 추적
    
    float error = target_yaw - current_yaw;
    while (error > 180.0) error -= 360.0;
    while (error <= -180.0) error += 360.0;
    
    // 실시간 방위 오차를 반영하여 모터 밸런스 교정 (가변 입력 속도 기준 적용)
    int correction = constrain((int)(error * HEADING_KP), -40, 40);
    int speed_A = constrain(current_speed + correction, 0, 255);
    int speed_B = constrain(current_speed - correction, 0, 255);
    
    controlMotor('A', speed_A); controlMotor('B', speed_B);
  } 
  else if (currentState == TURN) {
    if (abs(gyro_z_deg_per_sec) > 0.1) {
      gyro_accumulated_deg += (gyro_z_deg_per_sec * dt);
    }
    
    if (abs(gyro_accumulated_deg) >= abs(target_turn_angle)) {
      controlMotor('A', 0); controlMotor('B', 0);
      currentState = IDLE;
      Serial.println(">> [도달] 제자리 타겟 회전 미션 완료");
    } else {
      if (target_turn_angle > 0) { // 시계 방향 회전
        controlMotor('A', -TURN_SPEED); controlMotor('B', TURN_SPEED);
      } else { // 반시계 방향 회전
        controlMotor('A', TURN_SPEED);  controlMotor('B', -TURN_SPEED);
      }
    }
  }

  // 5. 상위 노드(라즈베리파이)로 하드웨어 상태 무선 피드백 송신 (50ms 주기)
  static unsigned long last_send_time = 0;
  if (client && client.connected() && (millis() - last_send_time >= 50)) {
    last_send_time = millis();
    client.print("MODE: ");
    if(currentState == IDLE) client.print("IDLE");
    else if(currentState == DRIVE_STRAIGHT) client.print("DRIVE");
    else if(currentState == TURN) client.print("TURN");

    client.print(" | Yaw: "); client.print(current_yaw);
    client.print(" | TurnAng: "); client.println(gyro_accumulated_deg);
  }

  delay(1); // 칩셋 과열 방지 및 백그라운드 태스크 스케줄링 양보
}

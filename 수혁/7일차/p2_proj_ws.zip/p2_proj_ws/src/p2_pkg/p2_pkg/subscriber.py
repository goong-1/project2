#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import CompressedImage  # ★ 일반 Image 대신 CompressedImage를 가져옵니다.
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
import cv2
import numpy as np  # ★ 압축 해제를 위한 넘파이 라이브러리

class ImageCompressedSubscriberNode(Node):
    def __init__(self):
        # ROS 2 노드 이름을 'image_compressed_subscriber_node'로 초기화합니다.
        super().__init__('image_compressed_subscriber_node')

        # [QoS 설정] 발행측(Publisher)의 BEST_EFFORT 설정과 일치시켜야 토픽이 정상적으로 수신됩니다.
        qos_profile = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )
        
        # ★ 'image_raw/compressed' 압축 토픽을 구독하는 subscriber 생성
        self.subscription = self.create_subscription(
            CompressedImage,
            'image_raw/compressed',
            self.compressed_image_callback,
            qos_profile
        )

        # ★ 'image_yolo/compressed' 압축 토픽을 구독하는 subscriber 생성
        #self.subscription = self.create_subscription(
        #   CompressedImage,
        #   'image_yolo/compressed',
        #   self.compressed_image_callback,
        #   qos_profile
        #)

        self.get_logger().info('리퍼블리셔 압축본 구독 노드가 정상 기동되었습니다. (/image_raw/compressed)')

    def compressed_image_callback(self, msg):
        try:
            # -----------------------------------------------------------
            # [핵심 단계] 압축된 JPEG 바이너리 데이터를 OpenCV 행렬(BGR)로 해제
            # -----------------------------------------------------------
            # 1. 수신한 바이트 데이터(msg.data)를 1차원 넘파이 배열로 변환
            np_arr = np.frombuffer(msg.data, np.uint8)
            
            # 2. 넘파이 배열을 JPEG 포맷에서 일반 BGR 이미지 이미지로 디코딩(압축 해제)
            cv_image = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
            
        except Exception as e:
            self.get_logger().error(f'압축 이미지 디코딩 실패: {e}')
            return

        if cv_image is not None:
            # -----------------------------------------------------------
            # [이미지 처리 영역] 여기서 라인 인식이나 YOLO 연산을 수행합니다.
            # -----------------------------------------------------------
            # 예시: 화면에 텍스트나 간단한 정보 표시
            h, w, _ = cv_image.shape
            cv2.putText(cv_image, f"Compressed Recv: {w}x{h}", (10, 20),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)

            # -----------------------------------------------------------
            # [화면 출력 영역] 모니터가 연결된 GUI 환경에서 디버깅 창 팝업
            # -----------------------------------------------------------
            cv2.imshow("Subscribed Compressed Image", cv_image)
            cv2.waitKey(1)  # 윈도우 창 갱신 및 이벤트를 처리하기 위한 1ms 대기 (필수)
        else:
            self.get_logger().warn('디코딩된 이미지 프레임이 비어 있습니다.')

def main(args=None):
    rclpy.init(args=args)
    node = ImageCompressedSubscriberNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        cv2.destroyAllWindows()  # 프로그램 종료 시 OpenCV가 열어둔 모든 윈도우 창 닫기
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
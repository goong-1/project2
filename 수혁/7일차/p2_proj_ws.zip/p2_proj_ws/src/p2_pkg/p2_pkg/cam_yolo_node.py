#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import CompressedImage  # ★ 결과 영상을 노트북으로 쏘기 위해 추가
from std_msgs.msg import String  # 최종 결과를 메인 노드로 넘겨줄 메시지 타입
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
import cv2
import numpy as np
import json
from pathlib import Path
import os

# 소스 코드 내부에서 ROS_DOMAIN_ID를 0번(기본 채널)으로 고정
os.environ['ROS_DOMAIN_ID'] = '0'

# 패키지에 포함되어 있는 비전 감지 알고리즘 라이브러리 로드
from p2_pkg.sign_detector import TrafficSignDetector

class CameraParserNode(Node):
    def __init__(self):
        super().__init__('camera_parser_node')

        # [라즈베리파이 서버 버전 최적화] 
        # 라즈베리파이 내부 창 띄우기는 완전히 끄고, 노트북 전송 모드를 활성화합니다.
        self.SHOW_DISPLAY = False 

        # 가중치 모델 파일(best.pt)의 절대 경로 빌드
        BASE_DIR = Path(__file__).resolve().parent
        MODEL_PATH = BASE_DIR / "best.pt"

        # sign_detector.py 라이브러리를 이용해 신뢰도 70% 기준으로 디텍터 초기화
        self.detector = TrafficSignDetector(
            model_path=str(MODEL_PATH),
            conf_threshold=0.70
        )

        # [QoS 설정] 이미지 통신을 위한 신뢰성 프로필
        image_qos_profile = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=5
        )

        # 라즈베리파이 카메라가 보내는 압축 이미지 수신
        self.image_sub = self.create_subscription(
            CompressedImage,
            'image_raw/compressed',
            self.image_callback,
            image_qos_profile
        )

        # 메인 제어 노드로 텍스트 정답을 쏴줄 발행자
        self.result_pub = self.create_publisher(String, 'traffic_sign_topic', 10)

        # ★ [추가] YOLO 디텍션 결과 화면을 노트북(WSL2)으로 송신할 압축 이미지 발행자 생성
        self.yolo_image_pub = self.create_publisher(
            CompressedImage, 
            'image_yolo/compressed', 
            image_qos_profile
        )

        self.last_print_time = self.get_clock().now()
        self.get_logger().info('==================================================')
        self.get_logger().info(' YOLO 압축 수신 및 결과 화면 노트북 송신 노드 가동 ')
        self.get_logger().info('==================================================')
        
        # =========================
        # ROI / one-shot publish 설정
        # =========================
        self.valid_actions = {"STOP", "GO", "SPEED_LIMIT", "TURN_LEFT"}
        self.roi_ratio = (0.10, 0.01, 0.90, 0.50)
        self.min_area_ratio = 0.010
        self.last_sent_action = None
        self.no_detection_count = 0
        self.reset_after_missing_frames = 10
        
    def image_callback(self, msg):
        try:
            # 수신된 CompressedImage 바이트 데이터를 OpenCV BGR8 이미지로 압축 해제
            frame = cv2.imdecode(np.frombuffer(msg.data, np.uint8), cv2.IMREAD_COLOR)
        except Exception as e:
            self.get_logger().error(f'압축 이미지 디코딩 변환 실패: {str(e)}')
            return

        if frame is None:
            return

        # 1. 전체 객체 탐지
        all_detections = self.detector.detect_all(frame)

        # 2. ROI 안에 있고 충분히 가까운 객체만 사용
        detections = self.filter_detections_by_roi(all_detections, frame)

        # 3. ROI 안에 유효 객체가 없어도 검출 화면(빈 박스/ROI 영역)은 노트북으로 전송합니다.
        if not detections:
            self.no_detection_count += 1
            if self.no_detection_count >= self.reset_after_missing_frames:
                self.last_sent_action = None

            # 노트북 전송용 디버그 프레임 생성 (아무것도 안 잡혔을 때의 화면)
            debug_frame = self.detector.draw_all(frame, detections)
            x1, y1, x2, y2 = self.get_roi_box(frame)
            cv2.rectangle(debug_frame, (x1, y1), (x2, y2), (255, 0, 0), 2)
            cv2.putText(debug_frame, "NO VALID DETECTION", (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
            
            # ★ 노트북으로 전송 함수 호출
            self.publish_yolo_frame(debug_frame, msg.header)
            return

        self.no_detection_count = 0

        # 4. 우선순위대로 대표 액션 1개 선택
        main_action = self.detector.get_main_action(detections)
        action_hint = main_action.get("action_hint", None)

        if action_hint not in self.valid_actions:
            return

        # 5. 같은 액션이 계속 보이면 중복 발행은 안 하되, 화면은 계속 업데이트해서 노트북으로 전송
        if action_hint == self.last_sent_action:
            debug_frame = self.detector.draw_all(frame, detections)
            x1, y1, x2, y2 = self.get_roi_box(frame)
            cv2.rectangle(debug_frame, (x1, y1), (x2, y2), (255, 0, 0), 2)
            cv2.putText(debug_frame, f"ALREADY SENT: {action_hint}", (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
            
            # ★ 노트북으로 전송 함수 호출
            self.publish_yolo_frame(debug_frame, msg.header)
            return

        # 6. 처음 본 액션만 메인 노드로 발행
        string_msg = String()
        string_msg.data = action_hint
        self.result_pub.publish(string_msg)
        self.last_sent_action = action_hint
        
        # 7. 새 객체가 검출된 화면 생성 및 노트북 전송
        debug_frame = self.detector.draw_all(frame, detections)
        x1, y1, x2, y2 = self.get_roi_box(frame)
        cv2.rectangle(debug_frame, (x1, y1), (x2, y2), (255, 0, 0), 2)
        cv2.putText(debug_frame, f"SENT: {action_hint}", (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
        
        # ★ 노트북으로 전송 함수 호출
        self.publish_yolo_frame(debug_frame, msg.header)

        # 터미널 폭주 방지를 위해 0.5초 주기로 추론 결과 로그 출력
        current_time = self.get_clock().now()
        elapsed_time = (current_time - self.last_print_time).nanoseconds / 1e9
        if elapsed_time > 0.5:
            self.get_logger().info(f'[YOLO AI Result] FINAL ACTION HINT -> {action_hint}')
            self.last_print_time = current_time

    # ★ [추가] OpenCV 디텍션 완료 화면을 JPEG 압축 토픽으로 노트북에 송신하는 헬퍼 함수
    def publish_yolo_frame(self, debug_frame, header):
        if debug_frame is not None:
            yolo_comp_msg = CompressedImage()
            yolo_comp_msg.header = header  # 타임스탬프 동기화
            yolo_comp_msg.format = "jpeg"
            
            # 320x240 해상도이므로 압축률 85 정도로 가볍게 송신
            _, encoded_img = cv2.imencode('.jpg', debug_frame, [int(cv2.IMWRITE_JPEG_QUALITY), 85])
            yolo_comp_msg.data = encoded_img.tobytes()
            
            # 'image_yolo/compressed' 토픽 발행
            self.yolo_image_pub.publish(yolo_comp_msg)
            
    def get_roi_box(self, frame):
        h, w = frame.shape[:2]
        rx1, ry1, rx2, ry2 = self.roi_ratio
        return int(w * rx1), int(h * ry1), int(w * rx2), int(h * ry2)

    def filter_detections_by_roi(self, detections, frame):
        roi_x1, roi_y1, roi_x2, roi_y2 = self.get_roi_box(frame)
        filtered = []
        for d in detections:
            try:
                act = d.action_hint
                area = d.area_ratio
                cx = d.center["x"]
                cy = d.center["y"]
            except AttributeError:
                act = d.get("action_hint")
                area = d.get("area_ratio")
                cx = d.get("center", {}).get("x", 0)
                cy = d.get("center", {}).get("y", 0)

            if act not in self.valid_actions or not (roi_x1 <= cx <= roi_x2 and roi_y1 <= cy <= roi_y2) or area < self.min_area_ratio:
                continue
            filtered.append(d)
        return filtered
    
def main(args=None):
    rclpy.init(args=args)
    node = CameraParserNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
#include <Arduino.h>
#include <WiFi.h>
#include <cmath>
#include "IMU.h"
#include "soc/soc.h"
#include "soc/rtc_cntl_reg.h"

// ==========================================
// [네트워크 고정 IP 및 서버 설정]
// ==========================================
const char* ssid = "asia-edu_2G";
const char* password = "12345678";

IPAddress local_IP(192, 168, 0, 9);
IPAddress gateway(192, 168, 0, 1);
IPAddress subnet(255, 255, 255, 0);

WiFiServer server(8080);

// ==========================================
// [핀 맵 설정]
// ==========================================
const uint16_t PWMA = 26; const uint16_t AIN1 = 22; const uint16_t AIN2 = 23;
const uint16_t PWMB = 25; const uint16_t BIN1 = 21; const uint16_t BIN2 = 17;
const uint16_t AENCA = 35; const uint16_t AENCB = 34;
const uint16_t BENCA = 27; const uint16_t BENCB = 16;

// ==========================================
// [엔코더 카운트 전역 변수]
// ==========================================
volatile long A_wheel_pulse_count = 0;
volatile long B_wheel_pulse_count = 0;
volatile int current_dir_A = 1;
volatile int current_dir_B = 1;

void IRAM_ATTR A_wheel_pulse() { A_wheel_pulse_count += current_dir_A; }
void IRAM_ATTR B_wheel_pulse() { B_wheel_pulse_count += current_dir_B; }

// ==========================================
// [튜닝 변수 및 물리 상수]
// ==========================================
const float MOTOR_A_WEIGHT = 1.01;
const float MOTOR_B_WEIGHT = 1.00;
const float TICKS_PER_CM = 725.875;
const float HEADING_KP = 1.2;
const int TURN_SPEED = 85;
const int CRUISE_SPEED = 127;

// ==========================================
// [제어 상태 및 센서 변수]
// ==========================================
enum RobotState { IDLE, DRIVE_STRAIGHT, TURN };
RobotState currentState = IDLE;

EulerAngles stAngles;
IMU_ST_SENSOR_DATA_FLOAT stGyroRawData, stAccelRawData;
IMU_ST_SENSOR_DATA stMagnRawData;

float target_yaw = 0.0;
float current_yaw = 0.0;
float gyro_z_offset = 0.0;
float gyro_accumulated_deg = 0.0;
float target_turn_angle = 0.0;
long target_ticks = 0;

String cmd_buffer = "";

// ==========================================
// [기본 함수 구현]
// ==========================================
void controlMotor(char motor, int speed) {
  uint16_t pwm_pin, in1_pin, in2_pin;
  float weight = 1.0;
  if (motor == 'A') {
    pwm_pin = PWMA; in1_pin = AIN1; in2_pin = AIN2; weight = MOTOR_A_WEIGHT;
  } else {
    pwm_pin = PWMB; in1_pin = BIN1; in2_pin = BIN2; weight = MOTOR_B_WEIGHT;
  }

  int final_speed = constrain((int)(speed * weight), -255, 255);

  if (final_speed > 0) {
    digitalWrite(in1_pin, HIGH); digitalWrite(in2_pin, LOW);
    ledcWrite(pwm_pin, final_speed);
  } else if (final_speed < 0) {
    digitalWrite(in1_pin, LOW); digitalWrite(in2_pin, HIGH);
    ledcWrite(pwm_pin, abs(final_speed));
  } else {
    digitalWrite(in1_pin, LOW); digitalWrite(in2_pin, LOW);
    ledcWrite(pwm_pin, 0);
  }
}

void calibrateGyro() {
  float sum = 0;
  int samples = 500;
  for (int i = 0; i < samples; i++) {
    imuDataGet(&stAngles, &stGyroRawData, &stAccelRawData, &stMagnRawData);
    sum += stGyroRawData.Z;
    delay(2);
  }
  gyro_z_offset = sum / samples;
}

void setup() {
  WRITE_PERI_REG(RTC_CNTL_BROWN_OUT_REG, 0);
  Serial.begin(115200);

  pinMode(AIN1, OUTPUT); pinMode(AIN2, OUTPUT);
  pinMode(BIN1, OUTPUT); pinMode(BIN2, OUTPUT);
  pinMode(AENCA, INPUT); pinMode(AENCB, INPUT);
  pinMode(BENCA, INPUT); pinMode(BENCB, INPUT);
  attachInterrupt(digitalPinToInterrupt(AENCA), A_wheel_pulse, RISING);
  attachInterrupt(digitalPinToInterrupt(BENCA), B_wheel_pulse, RISING);

  ledcAttach(PWMA, 20000, 8);
  ledcAttach(PWMB, 20000, 8);
  
  imuInit();
  delay(500);
  calibrateGyro();

  if (!WiFi.config(local_IP, gateway, subnet)) {
    Serial.println("고정 IP 주소 설정 실패!");
  }

  WiFi.begin(ssid, password);
  Serial.print("Wi-Fi 연결 중");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWi-Fi 연결 성공!");
  Serial.print("ESP32 고정 IP 주소: ");
  Serial.println(WiFi.localIP());

  server.begin();
}

void loop() {
  WiFiClient client = server.available();
  if (client) {
    Serial.println("원격 디버깅 단말기(파이썬) 무선 접속 성공!");
    cmd_buffer = "";
    currentState = IDLE;
    controlMotor('A', 0); controlMotor('B', 0);

    // 내부 제어 전용 시간축 변수 독립 선언
    unsigned long last_loop_time = micros();
    unsigned long last_send_time = millis();

    // 🔗 파이썬이 연결되어 있는 동안 완전히 독점 제어 루프를 가동 (블로킹 탈출)
    while (client.connected()) {
      unsigned long now = micros();
      float dt = (now - last_loop_time) / 1000000.0;
      last_loop_time = now;

      // 정밀 자이로 데이터 가동
      imuDataGet(&stAngles, &stGyroRawData, &stAccelRawData, &stMagnRawData);
      float gyro_z_deg_per_sec = (stGyroRawData.Z - gyro_z_offset);

      // 1. 수신 버퍼에 있는 패킷을 한 번에 끝까지 읽어오는 while 파싱 구조 개편
      while (client.available() > 0) {
        char c = client.read();
        if (c == '<') {
          cmd_buffer = "";
        } else if (c == '>') {
          if (cmd_buffer == "x") {
            currentState = IDLE;
            controlMotor('A', 0); controlMotor('B', 0);
            Serial.println(">> [명령] 긴급 제동");
          } 
          else if (cmd_buffer.startsWith("g,")) {
            float distance = cmd_buffer.substring(2).toFloat();
            target_ticks = (long)(distance * TICKS_PER_CM);
            noInterrupts();
            A_wheel_pulse_count = 0; B_wheel_pulse_count = 0;
            static_cast<void>(current_dir_A = 1); static_cast<void>(current_dir_B = 1);
            // 아키텍처 원본 로직에 부합하도록 직진 진입 순시 Yaw 각도를 타겟으로 락온
            target_yaw = current_yaw; 
            noInterrupts(); interrupts();
            currentState = DRIVE_STRAIGHT;
            Serial.println(">> [명령] 직진 기동 cm: " + String(distance));
          } 
          else if (cmd_buffer.startsWith("t,")) {
            target_turn_angle = cmd_buffer.substring(2).toFloat();
            gyro_accumulated_deg = 0.0;
            currentState = TURN;
            Serial.println(">> [명령] 회전 기동 deg: " + String(target_turn_angle));
          }
          cmd_buffer = "";
        } else {
          cmd_buffer += c;
        }
      }

      // 2. 상태 머신 구동 제어 핵심 처리부
      if (currentState == DRIVE_STRAIGHT) {
        current_yaw += (gyro_z_deg_per_sec * dt);
        if (abs(B_wheel_pulse_count) >= target_ticks) {
          controlMotor('A', 0); controlMotor('B', 0);
          currentState = IDLE;
          Serial.println(">> [도달] 직진 완료");
        } else {
          float error = target_yaw - current_yaw;
          while (error > 180.0) error -= 360.0;
          while (error <= -180.0) error += 360.0;
          int correction = constrain((int)(error * HEADING_KP), -40, 40);
          int speed_A = constrain(CRUISE_SPEED + correction, 0, 255);
          int speed_B = constrain(CRUISE_SPEED - correction, 0, 255);
          
          controlMotor('A', speed_A); controlMotor('B', speed_B);
        }
      } 
      else if (currentState == TURN) {
        if (abs(gyro_z_deg_per_sec) > 0.1) {
          gyro_accumulated_deg += (gyro_z_deg_per_sec * dt);
        }
        
        if (abs(gyro_accumulated_deg) >= abs(target_turn_angle)) {
          controlMotor('A', 0); controlMotor('B', 0);
          currentState = IDLE;
          Serial.println(">> [도달] 회전 완료 최종각: " + String(gyro_accumulated_deg));
        } else {
          if (target_turn_angle > 0) {
            controlMotor('A', -TURN_SPEED); controlMotor('B', TURN_SPEED);
          } else {
            controlMotor('A', TURN_SPEED);  controlMotor('B', -TURN_SPEED);
          }
        }
      }

      // 3. 파이썬 단말기로 무선 피드백 송신 (50ms 주기)
      if (millis() - last_send_time >= 50) {
        last_send_time = millis();
        client.print("MODE: ");
        if(currentState == IDLE) client.print("IDLE");
        else if(currentState == DRIVE_STRAIGHT) client.print("DRIVE");
        else if(currentState == TURN) client.print("TURN");

        client.print(" | AccYaw: "); client.print(gyro_accumulated_deg);
        client.print(" | CurYaw: "); client.print(current_yaw);
        client.print(" | EncB: "); client.println(B_wheel_pulse_count);
      }
      
      // 타이트한 루프 구동으로 인한 하드웨어 와치독 밥주기 및 통신 스케줄링 양보
      delay(1);
    }

    // 파이썬 연결 해제 시 로봇 정지 예방벽
    controlMotor('A', 0); controlMotor('B', 0);
    currentState = IDLE;
    Serial.println("원격 파이썬 단말기 연결 해제됨 -> 시스템 세이프 가드 작동");
  }
}
#!/usr/bin/env python3
import os
import threading
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import CompressedImage  
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
import cv2
import time

# ==============================================================================
# [핵심 추가] ROS_DOMAIN_ID 및 CycloneDDS 유니캐스트 환경 설정
# 반드시 rclpy.init()이 호출되기 전에 실행되어야 시스템에 정상 반영됩니다.
# ==============================================================================
# 1. ROS 도메인 ID를 30번으로 지정합니다. (문자열 형태로 입력 필수)
os.environ['ROS_DOMAIN_ID'] = '30'

# 2. 영상을 받아볼 수신측 2번 PC(노트북 등)의 실제 IP 주소를 적어주세요.
TARGET_IP_1 = "192.168.0.125" 
TARGET_IP_2 = "192.168.0.110"
TARGET_IP_3 = "192.168.0.155"
TARGET_IP_4 = "192.168.0.100"
# CycloneDDS 설정 XML 주입 (멀티캐스트 차단 및 특정 IP 지정을 동시에 수행)
os.environ['CYCLONEDDS_URI'] = f"""
<CycloneDDS>
    <Domain>
        <General>
            <AllowMulticast>false</AllowMulticast>
        </General>
        <Discovery>
            <Peers>
                <Peer Address="{TARGET_IP_1}"/>
                <Peer Address="{TARGET_IP_2}"/>
                <Peer Address="{TARGET_IP_3}"/>
                <Peer Address="{TARGET_IP_4}"/>
            </Peers>
            <ParticipantIndex>auto</ParticipantIndex>
        </Discovery>
    </Domain>
</CycloneDDS>
"""
# ==============================================================================

class CameraPublisherNode(Node):

    def __init__(self):
        super().__init__('camera_publisher_node')

        # 와이파이 환경 최적화용 QoS 설정 (최신 프레임 1개만 유지, BEST_EFFORT)
        qos_profile = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )
        
        # 압축 이미지 토픽 발행자만 선언
        self.compressed_publisher_ = self.create_publisher(CompressedImage, 'image_raw/compressed', qos_profile)
        
        DEVICE_ID = 0
        self.cap = cv2.VideoCapture(DEVICE_ID, cv2.CAP_V4L2)
        time.sleep(0.5)

        # 640x480 해상도 및 30 FPS 하드웨어 설정
        self.cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        self.cap.set(cv2.CAP_PROP_FPS, 30)
        self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

        if not self.cap.isOpened():
            self.get_logger().error('Ubuntu V4L2: 하드웨어 카메라 장치를 열 수 없습니다!')
            return

        # 백그라운드 프레임 캡처 스레드 안정화 레이어
        self.frame_lock = threading.Lock()
        self.latest_frame = None
        self.is_running = True
        
        # 카메라 데이터 수신 전용 백그라운드 스레드 구동
        self.capture_thread = threading.Thread(target=self._capture_loop, daemon=True)
        self.capture_thread.start()

        # 30 FPS 주기로 타이머 구동
        self.timer = self.create_timer(1.0 / 30.0, self.timer_callback)
        # 기존 코드 제거 후 아래 내용으로 교체
        self.get_logger().info(
            f'카메라 노드가 도메인 30번 및 지정된 IP들({TARGET_IP_1}, {TARGET_IP_2}, {TARGET_IP_3}, {TARGET_IP_4}) 전송 모드로 가동되었습니다.'
        )
    def _capture_loop(self):
        while self.is_running:
            ret, frame = self.cap.read()
            if ret and frame is not None:
                with self.frame_lock:
                    self.latest_frame = frame
            time.sleep(0.001)

    def timer_callback(self):
        frame = None
        with self.frame_lock:
            if self.latest_frame is not None:
                frame = self.latest_frame.copy()
        
        if frame is not None:
            if frame.shape[1] != 640 or frame.shape[0] != 480:
                frame = cv2.resize(frame, (640, 480))

            comp_msg = CompressedImage()
            comp_msg.header.stamp = self.get_clock().now().to_msg()
            comp_msg.header.frame_id = "camera_link"
            comp_msg.format = "jpeg"
            
            _, compressed_img = cv2.imencode('.jpg', frame, [int(cv2.IMWRITE_JPEG_QUALITY), 65])
            comp_msg.data = compressed_img.tobytes()
            
            self.compressed_publisher_.publish(comp_msg)
        else:
            self.get_logger().warn('카메라 장치로부터 비디오 프레임을 가져오지 못했습니다.')

def main(args=None):
    rclpy.init(args=args)
    node = CameraPublisherNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.is_running = False
        if node.cap.isOpened():
            node.cap.release()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()

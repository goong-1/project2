#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import CompressedImage
from rclpy.qos import qos_profile_sensor_data
from cv_bridge import CvBridge
import cv2
import numpy as np

class CamTestLineNode(Node):
    def __init__(self):
        super().__init__('cam_test_line_node')
        self.bridge = CvBridge() 
        
        # 압축 이미지 구독 설정
        self.image_sub = self.create_subscription(
            CompressedImage, 
            '/image_raw/compressed', 
            self.image_callback, 
            qos_profile_sensor_data
        )
        self.get_logger().info('Pipeline node optimized. 2nd window removed. Noise heavily filtered.')

    def image_callback(self, msg):
        try:
            # [창 1] 원본 화면 (Original)
            cv_image = self.bridge.compressed_imgmsg_to_cv2(msg, desired_encoding='bgr8')
            height, width, _ = cv_image.shape
            cv2.imshow("01_Original_Image", cv_image)
            
            # 내부 전처리: 흑백 변환 및 가우시안 블러 강도 강화 (5x5 -> 11x11)
            # 바닥의 미세 질감 노이즈를 완벽하게 지우기 위해 블러 강도를 높였습니다.
            gray = cv2.cvtColor(cv_image, cv2.COLOR_BGR2GRAY)
            blurred = cv2.GaussianBlur(gray, (11, 11), 0)

            # [창 3] 적응형 임계 처리 (Adaptive Threshold) - 노이즈 억제 파라미터 튜닝
            # 블록 사이즈를 51로 넓혀 전역적인 선 성분을 잡고, 상숫값 C를 10으로 올려 자잘한 노이즈를 차단합니다.
            adaptive_thresh = cv2.adaptiveThreshold(
                blurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
                cv2.THRESH_BINARY_INV, 51, 10
            )
            cv2.imshow("03_Adaptive_Threshold", adaptive_thresh)

            # [창 4] 캐니 엣지 처리 (Canny Edge)
            canny_edges = cv2.Canny(adaptive_thresh, 50, 150)
            cv2.imshow("04_Canny_Edge", canny_edges)

            # [창 5] 관심 영역 지정 처리 (사다리꼴 ROI Mask 적용)
            mask = np.zeros_like(canny_edges)
            polygon = np.array([[
                (int(width * 0.02), height),          
                (int(width * 0.35), int(height * 0.45)), 
                (int(width * 0.65), int(height * 0.45)), 
                (int(width * 0.88), height)           
            ]], np.int32)
            cv2.fillPoly(mask, polygon, 255)
            
            roi_result = cv2.bitwise_and(canny_edges, mask)
            cv2.imshow("05_Region_of_Interest_ROI", roi_result)

            # [창 6] 확률적 허프 변환 직선 검출 처리 (HoughLinesP)
            line_output_image = np.zeros((height, width, 3), np.uint8)
            lines = cv2.HoughLinesP(roi_result, rho=1, theta=np.pi/180, threshold=25, minLineLength=25, maxLineGap=45)

            if lines is not None:
                for line in lines:
                    x1, y1, x2, y2 = line[0]
                    
                    if x2 - x1 == 0:
                        slope = 999.0
                    else:
                        slope = (y2 - y1) / (x2 - x1)
                    
                    # (A) 가로선 필터링: 강한 수평 성분 노이즈 제거 (빨간색)
                    if abs(slope) < 0.20:
                        cv2.line(line_output_image, (x1, y1), (x2, y2), (0, 0, 255), 4)
                        
                    # (B) 세로 성분 차선 주행선 필터링
                    else:
                        line_center_x = (x1 + x2) / 2
                        
                        # 화면의 좌측 대역 차선 (왼쪽 노랑 실선 -> 노란색 표시)
                        if line_center_x < (width * 0.40):
                            cv2.line(line_output_image, (x1, y1), (x2, y2), (0, 255, 255), 3)
                            
                        # 화면의 우측 대역 차선 (오른쪽 노랑 실선 -> 노란색 표시)
                        elif line_center_x > (width * 0.60):
                            cv2.line(line_output_image, (x1, y1), (x2, y2), (0, 255, 255), 3)
                            
                        # 화면 정중앙 영역 축 (중앙 검정색 점선 차선 -> 초록색 표시)
                        else:
                            cv2.line(line_output_image, (x1, y1), (x2, y2), (0, 255, 0), 3)

            cv2.imshow("06_Hough_Line_Detection", line_output_image)
            
            # OpenCV GUI 스레드 메시지 루프 갱신
            cv2.waitKey(1)
            
        except Exception as e:
            self.get_logger().error(f'Error during image processing: {e}')

def main(args=None):
    rclpy.init(args=args)
    node = CamTestLineNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        cv2.destroyAllWindows() 
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
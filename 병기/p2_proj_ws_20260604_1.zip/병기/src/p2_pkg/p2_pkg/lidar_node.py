#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from std_msgs.msg import Float32MultiArray  # Wi-Fi 원격 전송용 배열 메시지 타입 추가
from rclpy.qos import qos_profile_sensor_data, QoSProfile, QoSReliabilityPolicy, QoSHistoryPolicy
import math

class LidarFilterSubscriber(Node):
    def __init__(self):
        super().__init__('lidar_filter_subscriber')
        
        # [수정 불가 제어 핵심 임계값 변수]
        self.front_min_distance = 1.0   # 정면 장애물 감지 한계 기준 거리 (1.0m)
        self.angle_range_deg = 10.0     # 정면 기준 좌우 10도 (총 20도 옥탄트 부채꼴 영역)

        # 원본 라이다 데이터 구독
        self.scan_sub = self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_callback,
            qos_profile_sensor_data
        )
        
        # Rviz2 시각화용 QoS 프로파일 설정
        custom_qos = QoSProfile(
            reliability=QoSReliabilityPolicy.BEST_EFFORT,
            history=QoSHistoryPolicy.KEEP_LAST,
            depth=10
        )
        
        # 필터링된 라이다 데이터를 Rviz2로 보낼 퍼블리셔
        self.filtered_scan_pub = self.create_publisher(
            LaserScan,
            '/filtered_scan',
            custom_qos
        )
        
        # =========================================================================
        # [추가] Wi-Fi망을 통해 제어기/디스플레이로 판단 데이터를 전송할 퍼블리셔
        # =========================================================================
        self.wifi_status_pub = self.create_publisher(
            Float32MultiArray,
            '/obstacle_status', 
            custom_qos
        )
        
        # 실시간 제어 캐시 메모리 레지스터
        self.obstacle_detected = False
        self.closest_obstacle_distance = 0.0
        self.get_logger().info('D200 실측 정밀 처리 및 Wi-Fi 데이터 팩킹 컴포넌트 로드 완료.')

    def scan_callback(self, msg):
        """ 드라이버 정제 미터(m) 수치를 기반으로 정면 실시간 필터링 실행 """
        self.obstacle_detected = False
        min_detected_dist = float('inf') 
        angle_range_rad = math.radians(self.angle_range_deg)
        
        # Rviz2 전송용 필터링 데이터 구조 초기화
        filtered_msg = LaserScan()
        filtered_msg.header = msg.header
        filtered_msg.angle_min = msg.angle_min
        filtered_msg.angle_max = msg.angle_max
        filtered_msg.angle_increment = msg.angle_increment
        filtered_msg.time_increment = msg.time_increment
        filtered_msg.scan_time = msg.scan_time
        filtered_msg.range_min = msg.range_min
        filtered_msg.range_max = msg.range_max
        
        # 기본적으로 모든 각도의 거리를 무한대(inf)로 채워둡니다.
        filtered_msg.ranges = [float('inf')] * len(msg.ranges)
        
        for i, distance in enumerate(msg.ranges):
            # 결측치 노이즈 필터 차단
            if distance < msg.range_min or distance > msg.range_max or math.isinf(distance) or math.isnan(distance):
                continue
                
            current_angle = msg.angle_min + (i * msg.angle_increment)
            
            # 정면 감지각 바운더리 검사
            if -angle_range_rad <= current_angle <= angle_range_rad:
                filtered_msg.ranges[i] = distance
                
                # 제어용 충돌 임계값 안쪽인지 판정
                if distance < self.front_min_distance:
                    self.obstacle_detected = True
                    if distance < min_detected_dist:
                        min_detected_dist = distance
                        
        # 결과 필터값 상태 갱신
        if self.obstacle_detected:
            self.closest_obstacle_distance = min_detected_dist
        else:
            self.closest_obstacle_distance = 0.0
            
        # Rviz2용 토픽 발행
        self.filtered_scan_pub.publish(filtered_msg)
                    
        # 실시간 제어 상태 판정 및 Wi-Fi 토픽 송신 실행
        self.process_obstacle_status()

    def process_obstacle_status(self):
        """ 실시간 감지 레벨에 따른 경고 로그 핸들러 및 Wi-Fi 통신 데이터 방출 """
        
        # Wi-Fi 전송용 배열 구조체 데이터 빌드
        status_msg = Float32MultiArray()
        
        if self.obstacle_detected:
            self.get_logger().warn(f'![위험] 정면 장애물 발견: {self.closest_obstacle_distance:.3f}m')
            # [배열 데이터 정의] 1.0: 위험 상태 의미, 두번째는 실측 제어 거리
            status_msg.data = [1.0, float(self.closest_obstacle_distance)]
        else:
            self.get_logger().info('전방 안전 확보됨.')
            # [배열 데이터 정의] 0.0: 안전 상태 의미, 두번째는 거리 없음(0.0)
            status_msg.data = [0.0, 0.0]
            
        # =========================================================================
        # 동일 Wi-Fi 대역폭 네트워크상의 서브 장치들로 데이터 일괄 브로드캐스팅
        # =========================================================================
        self.wifi_status_pub.publish(status_msg)

def main(args=None):
    rclpy.init(args=args)
    node = LidarFilterSubscriber()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
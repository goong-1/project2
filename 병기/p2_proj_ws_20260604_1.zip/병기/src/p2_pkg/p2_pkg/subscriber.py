#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import CompressedImage  
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
import cv2
import numpy as np  

class ImageCompressedSubscriberNode(Node):
    def __init__(self):
        super().__init__('image_compressed_subscriber_node')

        # 발행 노드의 무선 최적화 프로파일(BEST_EFFORT)과 매칭 처리
        qos_profile = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )

        select_img_type = 0
        if (select_img_type == 0):
            self.subscription = self.create_subscription(
                CompressedImage,
                'image_raw/compressed',
                self.compressed_image_callback,
                qos_profile
            )
            self.get_logger().info('압축 이미지 수신 노드가 기동되었습니다. (/image_raw/compressed, 640x480 모드)')
        elif (select_img_type == 1):
            self.subscription = self.create_subscription(
                CompressedImage,
                'image_yolo/compressed',
                self.compressed_image_callback,
                qos_profile
            )
        elif (select_img_type == 2):
            self.subscription = self.create_subscription(
                CompressedImage,
                'image_line/compressed',
                self.compressed_image_callback,
                qos_profile
            )

    def compressed_image_callback(self, msg):
        try:
            # 와이파이 패킷으로 들어온 이진 버퍼 데이터 언팩
            np_arr = np.frombuffer(msg.data, np.uint8)
            cv_image = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
            
            # 무선 통신 불안정으로 인해 완전히 깨진 패킷 유입 시 크래시 가드 인터셉트
            if cv_image is None:
                self.get_logger().warn('와이파이 수신 제한으로 손상된 이미지 패킷을 건너뜁니다.')
                return

        except Exception as e:
            self.get_logger().error(f'압축 이미지 디코딩 실패: {e}')
            return

        if cv_image is not None:
            # [수정] 실시간 수신 화면 가이드라인 해상도를 640x480 강제 바인딩 매칭
            if cv_image.shape[1] != 640 or cv_image.shape[0] != 480:
                cv_image = cv2.resize(cv_image, (640, 480))

            h, w, _ = cv_image.shape
            cv2.putText(cv_image, f"WiFi Recv: {w}x{h}", (10, 20),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)

            # WSL2 가상 그래픽 렌더링 팅김을 막기 위해 waitKey 타임아웃을 10ms로 할당하여 화면 갱신 유도
            cv2.imshow("Subscribed Compressed Image", cv_image)
            cv2.waitKey(10) 
        else:
            self.get_logger().warn('디코딩된 이미지 프레임이 비어 있습니다.')

def main(args=None):
    rclpy.init(args=args)
    node = ImageCompressedSubscriberNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        cv2.destroyAllWindows()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
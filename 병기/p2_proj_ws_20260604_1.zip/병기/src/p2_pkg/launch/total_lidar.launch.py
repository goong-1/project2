#!/usr/bin/env python3
import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node

def generate_launch_description():
    ldlidar_launch_dir = os.path.join(
        get_package_share_directory('ldlidar_stl_ros2'),
        'launch'
    )
    
    ldlidar_driver = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(ldlidar_launch_dir, 'ld06.launch.py')
        ),
        launch_arguments={'serial_port': '/dev/ttyUSB0'}.items()
    )

    my_lidar_filter_node = Node(
        package='p2_pkg',
        executable='lidar_node',
        name='lidar_filter_subscriber',
        output='screen'
    )

    # 이벤트 핸들러 없이 두 개를 한 번에 런치 실행 목록에 넣음
    return LaunchDescription([
        ldlidar_driver,
        my_lidar_filter_node
    ])
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
# 아래 줄을 정확하게 추가해야 합니다.
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
import cv2
from cv_bridge import CvBridge

class CameraPublisher(Node):
    def __init__(self):
        super().__init__('camera_publisher')

        # 1. QoS 설정: 데이터 유실 방지를 위해 신뢰성(Reliable) 모드 적용
        # 이제 QoSProfile을 정상적으로 사용할 수 있습니다.
        qos_profile = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )
        
        self.publisher_ = self.create_publisher(Image, 'video_frames', 10)
        self.br = CvBridge()

        # V4L2 백엔드 사용
        self.cap = cv2.VideoCapture(0, cv2.CAP_V4L2)
        
        # 데이터 안정성을 위해 해상도를 640x480으로 설정 (테스트용)
        self.cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 2)

        if not self.cap.isOpened():
            self.get_logger().error('카메라를 열 수 없습니다!')
            return

        self.timer = self.create_timer(0.1, self.timer_callback)
        self.get_logger().info('카메라 노드 시작됨 (640x480 MJPG)')

    def timer_callback(self):
        ret, frame = self.cap.read()
        if ret:
            # 이미지 전송 전 로그 출력 (디버깅용)
            msg = self.br.cv2_to_imgmsg(frame, encoding="bgr8")
            self.publisher_.publish(msg)
        else:
            self.get_logger().warn('프레임을 읽지 못했습니다.')

def main(args=None):
    rclpy.init(args=args)
    node = CameraPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if node.cap.isOpened():
            node.cap.release()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
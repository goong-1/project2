#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist

# 💡 [중요 수정] _node 명칭이 붙은 파일명 구조에서 클래스를 임포트하도록 주소 업데이트 완료
from p2_pkg.lidar_parser_node import LidarParser
from p2_pkg.camera_parser_node import CameraParser
from p2_pkg.motor_driver_node import MotorDriver

class CentralMainController(Node):
    def __init__(self):
        super().__init__('central_main_controller')
        
        # 1. 분리 모듈 독립 초기화 연동
        self.lidar = LidarParser(self.get_logger())
        self.camera = CameraParser(self.get_logger())
        self.motor = MotorDriver(self.get_logger())
        
        # 2. ROS 2 인프라 인터페이스 선언 및 매칭
        self.scan_sub = self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_callback,
            10
        )
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        
        # 3. 중앙 집중형 자율주행 상태 변수 관리
        self.current_lane = 1          # 1차선 기본 주행 시작
        self.is_changing_lane = False  # 차로 변경 시퀀스 플래그
        self.lane_change_step = 0
        self.step_timer = 0
        self.turn_direction = 0.0
        self.target_lane = 1
        
        self.get_logger().info('==================================================')
        self.get_logger().info(' Central Main Control System is fully operational. ')
        self.get_logger().info('==================================================')

    def scan_callback(self, msg):
        """ 라이다 데이터가 들어올 때마다 상태를 분석하고 모터 제어 명령을 하향 하달하는 메인 루프 """
        if self.is_changing_lane:
            self.execute_lane_change_sequence()
            return

        # [라이다 모듈 연동] 전방 40cm 장애물 여부 판단 추출
        obstacle_detected = self.lidar.parse_scan_data(msg)
        
        if obstacle_detected:
            # 장애물 직면 시 모터 드라이버 모듈을 통해 정지 명령 생성 후 발행
            stop_cmd = self.motor.get_control_command('STOP')
            self.cmd_pub.publish(stop_cmd)
            
            # 주행 차선 플래닝 분기 함수 진입
            self.plan_lane_change()
        else:
            # 장애물이 없으면 모터 드라이버 모듈의 밸런스 직진 명령을 생성 후 발행
            forward_cmd = self.motor.get_control_command('FORWARD')
            self.cmd_pub.publish(forward_cmd)

    def plan_lane_change(self):
        """ 현재 차로 위치에 맞춰 타겟 차선과 피벗 회전 방향을 연산하는 횡방향 플래닝부 """
        if self.current_lane == 1:
            self.get_logger().info('[Main Central] Lane Change Event: 1차선 -> 2차선 진입 확정')
            self.target_lane = 2
            self.turn_direction = -1.0 # 우회전 피벗턴 방향 지시
        else:
            self.get_logger().info('[Main Central] Lane Change Event: 2차선 -> 1차선 진입 확정')
            self.target_lane = 1
            self.turn_direction = 1.0  # 좌회전 피벗턴 방향 지시
            
        self.is_changing_lane = True
        self.lane_change_step = 1
        self.step_timer = 0

    def execute_lane_change_sequence(self):
        """ 메인 타이머 루프에 바인딩되어 물리 바퀴 이동 프로필을 순차 처리하는 제어 시퀀스 """
        self.step_timer += 1
        motor_mode = 'STOP'
        
        # [Step 1] 주행 각도를 대각선 차선 방향으로 꺾기 위한 제자리 회전 (Pivot Turn)
        if self.lane_change_step == 1:
            motor_mode = 'PIVOT_RIGHT' if self.turn_direction == -1.0 else 'PIVOT_LEFT'
            if self.step_timer > 30:
                self.lane_change_step = 2
                self.step_timer = 0
                
        # [Step 2] 옆 차선 정중앙 영역으로 파고들기 위한 대각선 직진 주행
        elif self.lane_change_step == 2:
            motor_mode = 'FORWARD'
            if self.step_timer > 50:
                self.lane_change_step = 3
                self.step_timer = 0
                
        # [Step 3] 옆 차선 안착 후 도로 수평 정렬을 맞추기 위한 반대 방향 복귀 회전
        elif self.lane_change_step == 3:
            motor_mode = 'PIVOT_LEFT' if self.turn_direction == -1.0 else 'PIVOT_RIGHT'
            if self.step_timer > 30:
                self.lane_change_step = 4
                self.step_timer = 0
                
        # [Step 4] 차로 이동 상태 변수를 타겟 차선으로 완전 동기화 및 일반 주행 제어권 복귀
        elif self.lane_change_step == 4:
            self.current_lane = self.target_lane
            self.is_changing_lane = False
            self.get_logger().info(f'[Main Central] SUCCESS: Vehicles Arrived at Lane {self.current_lane}')
            motor_mode = 'FORWARD'

        # 최종 선택된 제어 모드의 Twist 신호를 모터 모듈로부터 빌드하여 하드웨어단에 최종 전송
        control_msg = self.motor.get_control_command(motor_mode)
        self.cmd_pub.publish(control_msg)

def main(args=None):
    rclpy.init(args=args)
    node = CentralMainController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
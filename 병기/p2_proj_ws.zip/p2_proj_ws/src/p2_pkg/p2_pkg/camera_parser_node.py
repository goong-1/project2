#!/usr/bin/env python3

class CameraParser:
    def __init__(self, node_logger):
        self.logger = node_logger
        self.traffic_light_color = "GREEN"  # 기본값 상태 지정
        self.lane_offset = 0.0              # 기본값 상태 지정

    def parse_image_data(self, cv_image):
        """ 
        OpenCV 이미지 프레임을 입력받아 신호등 및 차선 정보를 갱신하는 영역
        (향후 카메라 기능 추가 시 이 함수 내부에 알고리즘 구현)
        """
        pass
        return self.traffic_light_color, self.lane_offset
    
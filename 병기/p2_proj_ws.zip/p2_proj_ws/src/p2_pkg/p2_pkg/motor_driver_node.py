#!/usr/bin/env python3
from geometry_msgs.msg import Twist

class MotorDriver:
    def __init__(self, node_logger):
        self.logger = node_logger
        
        # 유저 하드웨어 사양 정밀 보정치 반영 (좌: 108, 우: 110 밸런스 매칭)
        self.LEFT_PWM_BALANCED = 108
        self.RIGHT_PWM_BALANCED = 110
        
        # 내부 주행 물리 제어 상수
        self.BASE_FORWARD_SPEED = 0.15
        self.PIVOT_TURN_SPEED = 0.5

    def get_control_command(self, mode):
        """ 제어 모드를 입력받아 ROS 2 하드웨어 제어 규격인 Twist 메시지를 생성 및 반환 """
        twist = Twist()
        
        if mode == 'FORWARD':
            self.logger.info(f'[Motor Module] FORWARD -> PWM [L: {self.LEFT_PWM_BALANCED} / R: {self.RIGHT_PWM_BALANCED}]')
            twist.linear.x = self.BASE_FORWARD_SPEED
            twist.angular.z = 0.0
            
        elif mode == 'PIVOT_LEFT':
            self.logger.info(f'[Motor Module] PIVOT_LEFT (On-the-spot Rotation) -> PWM [L: {self.LEFT_PWM_BALANCED} / R: {self.RIGHT_PWM_BALANCED}]')
            twist.linear.x = 0.0
            twist.angular.z = self.PIVOT_TURN_SPEED
            
        elif mode == 'PIVOT_RIGHT':
            self.logger.info(f'[Motor Module] PIVOT_RIGHT (On-the-spot Rotation) -> PWM [L: {self.LEFT_PWM_BALANCED} / R: {self.RIGHT_PWM_BALANCED}]')
            twist.linear.x = 0.0
            twist.angular.z = -self.PIVOT_TURN_SPEED
            
        elif mode == 'STOP':
            self.logger.info('[Motor Module] STOP -> PWM [L: 0 / R: 0]')
            twist.linear.x = 0.0
            twist.angular.z = 0.0
            
        return twist
    
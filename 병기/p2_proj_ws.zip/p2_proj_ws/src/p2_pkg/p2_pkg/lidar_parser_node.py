#!/usr/bin/env python3
import math

class LidarParser:
    def __init__(self, node_logger):
        self.logger = node_logger
        self.front_min_distance = 0.4  # 장애물 감지 안전 기준 거리 (40cm)
        self.angle_range_deg = 30.0    # 정면 기준 좌우 30도 (총 60도 부채꼴)

    def parse_scan_data(self, msg):
        """ LaserScan 메시지를 입력받아 전방 장애물 존재 여부를 반환 """
        obstacle_detected = False
        angle_range_rad = math.radians(self.angle_range_deg)
        
        for i, distance in enumerate(msg.ranges):
            # 유효하지 않은 측정 데이터 범위 제외
            if distance < msg.range_min or distance > msg.range_max:
                continue
                
            # 각 레이저 빔의 실제 방사 각도 계산
            current_angle = msg.angle_min + (i * msg.angle_increment)
            
            # 정면 지정 각도 내 필터링
            if -angle_range_rad <= current_angle <= angle_range_rad:
                if distance < self.front_min_distance:
                    obstacle_detected = True
                    self.logger.warn(f'[Lidar Module] Obstacle Detected! Distance: {distance:.2f}m')
                    break
                    
        return obstacle_detected
    
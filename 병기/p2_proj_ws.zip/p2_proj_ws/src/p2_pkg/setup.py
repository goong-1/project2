from setuptools import find_packages, setup

package_name = 'p2_pkg'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='user',
    maintainer_email='user@todo.todo',
    description='ROS 2 Jazzy Autonomous Lane Change Project Package',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            # 1. 중앙 메인 제어 컨트롤러 노드 진입점
            'p2_proj_node = p2_pkg.p2_proj_node:main',
            
            # 2. 라이다 데이터 인지 및 파싱 노드 진입점 (추후 단독 가동 대비)
            'lidar_parser_node = p2_pkg.lidar_parser_node:main',
            
            # 3. 카메라 데이터 인지 및 비전 파싱 노드 진입점 (확장용)
            'camera_parser_node = p2_pkg.camera_parser_node:main',
            
            # 4. 하드웨어 모터 드라이버 인터페이스 제어 노드 진입점
            'motor_driver_node = p2_pkg.motor_driver_node:main',
        ],
    },
)
def main():
    print('Hi from p2_pkg.')


if __name__ == '__main__':
    main()

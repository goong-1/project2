import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64, String

class TrafficLightController(Node):
    def __init__(self):
        super().__init__('traffic_light_controller')
        
        # 1. Gazebo 가림막 위치 제어용 토픽 (Float64)
        self.cmd_pub = self.create_publisher(Float64, '/traffic_light/cmd_pos', 10)
        # 2. 로봇(tracking_node) 구동 로직 연동용 상태 토픽 (String)
        self.state_pub = self.create_publisher(String, '/traffic_light/state', 10)
        
        # 7초 간격 타이머 설정
        self.timer = self.create_timer(7.0, self.timer_callback)
        self.is_green = True
        
        self.get_logger().info("🚦 신호등 제어 노드가 시작되었습니다. (7초 주기)")
        self.timer_callback() # 노드 켜지자마자 즉시 1회 실행

    def timer_callback(self):
        cmd_msg = Float64()
        state_msg = String()
        
        if self.is_green:
            cmd_msg.data = 0.0125  # 가림막을 위로(+Z) 올려서 빨강/노랑을 가림 (초록불 점등)
            state_msg.data = "GREEN"
            self.get_logger().info("🟢 초록불 점등!")
        else:
            cmd_msg.data = -0.0125 # 가림막을 아래로(-Z) 내려서 초록/노랑을 가림 (빨간불 점등)
            state_msg.data = "RED"
            self.get_logger().info("🔴 빨간불 점등!")
            
        self.cmd_pub.publish(cmd_msg)
        self.state_pub.publish(state_msg)
        
        # 다음 주기를 위해 상태 반전
        self.is_green = not self.is_green

def main(args=None):
    rclpy.init(args=args)
    node = TrafficLightController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()

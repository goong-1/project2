#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import String  # 최종 결과를 메인 노드로 넘겨줄 메시지 타입
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
from cv_bridge import CvBridge
import cv2
import json
from pathlib import Path

# 패키지에 포함되어 있는 비전 감지 알고리즘 라이브러리 로드
from p2_pkg.sign_detector import TrafficSignDetector

class CameraParserNode(Node):
    def __init__(self):
        super().__init__('camera_parser_node')
        self.br = CvBridge()

        # [디버깅 디스플레이 옵션]
        # WSL2나 가상환경 환경에서 윈도우 창(imshow)을 띄우려면 True로 설정하세요.
        # 터미널 로그로만 확인하고 싶다면 False로 두시면 됩니다.
        self.SHOW_DISPLAY = False 

        # 가중치 모델 파일(best_v2.pt)의 절대 경로 빌드
        BASE_DIR = Path(__file__).resolve().parent
        MODEL_PATH = BASE_DIR / "best_v2.pt"

        # sign_detector.py 라이브러리를 이용해 신뢰도 70% 기준으로 디텍터 초기화
        self.detector = TrafficSignDetector(
            model_path=str(MODEL_PATH),
            conf_threshold=0.70
        )

        # 이미지 수신용 기본 큐 사이즈 설정
        self.image_sub = self.create_subscription(
            Image,
            'video_frames',
            self.image_callback,
            10
        )

        # 메인 노드로 텍스트 정답을 쏴줄 발행자 생성
        self.result_pub = self.create_publisher(String, 'traffic_sign_topic', 10)

        self.last_print_time = self.get_clock().now()
        self.get_logger().info('==================================================')
        self.get_logger().info(' YOLO 기반 비전 분석 파서 노드가 정상 기동되었습니다. ')
        self.get_logger().info('==================================================')

    def image_callback(self, msg):
        try:
            # 수신된 ROS 2 이미지를 OpenCV Matrix 데이터 포맷으로 변환
            frame = self.br.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        except Exception as e:
            self.get_logger().error(f'이미지 디코딩 변환 실패: {str(e)}')
            return

        # 1. sign_detector 알고리즘에 따른 전방 모든 객체 탐지
        detections = self.detector.detect_all(frame)

        # 2. 가장 우선순위가 높은 메인 주행 액션 규칙 1개 추출
        main_action = self.detector.get_main_action(detections)
        action_hint = main_action.get("action_hint", "UNKNOWN")
        
        # 3. 추출된 제어 지시 힌트(GO, STOP 등)를 토픽으로 발행
        string_msg = String()
        string_msg.data = action_hint
        self.result_pub.publish(string_msg)

        # 4. 터미널 폭주 방지를 위해 0.5초 주기로 추론 결과 출력
        current_time = self.get_clock().now()
        elapsed_time = (current_time - self.last_print_time).nanoseconds / 1e9
        
        if elapsed_time > 0.5:
            self.get_logger().info(f'[YOLO AI Result] FINAL ACTION HINT -> {action_hint}')
            self.last_print_time = current_time

        # 5. 화면 디스플레이 플래그가 True일 때 윈도우 창 시각화
        if self.SHOW_DISPLAY:
            annotated_frame = self.detector.draw_all(frame, detections)
            cv2.imshow("Traffic Sign Detection (ROS2)", annotated_frame)
            cv2.waitKey(1)

def main(args=None):
    rclpy.init(args=args)
    node = CameraParserNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        cv2.destroyAllWindows()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
from std_msgs.msg import String
import math

class CentralMainController(Node):
    def __init__(self):
        super().__init__('central_main_controller')
        
        # =========================================================================
        # [구조 통합 1] 라이다 데이터 처리를 위한 필터링 파라미터 상수 정의
        # =========================================================================
        self.front_min_distance = 0.4   # 정면 장애물 감지 안전 유격 거리 (40cm)
        self.angle_range_deg = 30.0     # 정면 0도 기준 좌측 30도, 우측 30도 (총 60도 부채꼴 영역 스캔)

        # =========================================================================
        # [구조 통합 2] 유저 하드웨어 전용 모터 드라이버 제어 속성 보정치 이식
        # =========================================================================
        self.LEFT_PWM_BALANCED = 108    # 양쪽 모터 토크 편차 균형을 위한 좌측 전용 파워 매칭
        self.RIGHT_PWM_BALANCED = 110   # 양쪽 모터 토크 편차 균형을 위한 우측 전용 파워 매칭
        self.BASE_FORWARD_SPEED = 0.15  # 평시 정속 주행 선속도 (m/s)
        self.PIVOT_TURN_SPEED = 0.5     # 제자리 역회전(Pivot Turn) 구동을 위한 각속도 (rad/s)
        
        # =========================================================================
        # [ROS 2 인터페이스] 외부 통신 토픽 바인딩
        # =========================================================================
        # 라이다 드라이버 패키지(lidar_pkg)에서 보낸 데이터를 구독
        self.scan_sub = self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_callback,
            10
        )
        
        # camera_parser_node(YOLO)가 축약해 보낸 신호 상태 토픽을 구독
        self.camera_sub = self.create_subscription(
            String,
            'traffic_sign_topic',
            self.camera_callback,
            10
        )
        
        # 로봇 하드웨어 컨트롤 보드로 최종 모터 제어 벡터를 송신할 발행자 생성
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        
        # =========================================================================
        # [자율주행 제어 오토마타 변수] 차량 상태 파라미터 초기화
        # =========================================================================
        self.current_lane = 1          # 출발 기본 상태 차선 (1차선 주행 중)
        self.is_changing_lane = False  # 차로 변경 시퀀스 실행 중 여부 플래그
        self.lane_change_step = 0      # 단계별 주행 타이머 시퀀스 스텝 번호
        self.step_timer = 0            # 각 스텝별 가상 프레임 카운팅 타임 레지스터
        self.turn_direction = 0.0      # 좌/우회전 방향 지시 부호 (우향 -1.0, 좌향 1.0)
        self.target_lane = 1           # 진입하고자 하는 목적지 차선 번호
        
        # 실시간 센서 파싱 원시 값 저장용 캐시 변수
        self.traffic_light_status = "UNKNOWN"
        self.obstacle_detected = False

        self.get_logger().info('==================================================')
        self.get_logger().info(' 중앙 통합 컨트롤러 및 모터 직접 제어 엔진 가동 개시 ')
        self.get_logger().info('==================================================')

    def camera_callback(self, msg):
        """ YOLO 노드가 발행한 신호 텍스트를 두뇌 변수에 실시간 동기화 복사 """
        self.traffic_light_status = msg.data

    def scan_callback(self, msg):
        """ [구 lidar_parser_node 통합] 별도의 토픽 발행 단계를 삭제하고 인라인으로 데이터 파싱 연산 수행 """
        self.obstacle_detected = False
        angle_range_rad = math.radians(self.angle_range_deg)
        
        for i, distance in enumerate(msg.ranges):
            # 측정 불가능 범위 데이터 제외 예외처리
            if distance < msg.range_min or distance > msg.range_max:
                continue
                
            # 배열 인덱스를 기준으로 해당 샘플 레이저의 각도 환산
            current_angle = msg.angle_min + (i * msg.angle_increment)
            
            # 지정한 좌우 부채꼴 범위 안에 들어왔는지 필터링
            if -angle_range_rad <= current_angle <= angle_range_rad:
                # 감지 한계 충돌선인 40cm보다 가깝다면 장애물 감지 확정 처리
                if distance < self.front_min_distance:
                    self.obstacle_detected = True
                    break
                    
        # 센서 데이터 수집 주기에 맞춰 가동 중앙 의사결정 제어 루프 진입
        self.control_loop()

    def control_loop(self):
        """ [중앙 제어 타워 핵심] 센서 취합 결과를 바탕으로 명령 우선순위를 교통 정리하여 단 하나의 Twist만 모터로 하사 """
        
        # 이미 차선 변경 연산이 돌아가고 있다면 타이머 기반 스케줄러 시퀀스에 제어권을 전권 위임
        if self.is_changing_lane:
            self.execute_lane_change_sequence()
            return

        # [우선순위 1] 비전 분석 결과 빨간불(STOP)이 감지되었는가? -> 하드웨어 무조건 일시 정지
        if self.traffic_light_status == "STOP":
            self.get_logger().info('[Main Brain] 비전 차단: 정지 신호등 또는 STOP 표지판 발견! 차량 대기.')
            self.publish_motor_command('STOP')
            return

        # [우선순위 2] 라이다 센싱 결과 전방에 장애물이 있는가? -> 회피용 차로 변경 스케줄링 플래닝 돌입
        if self.obstacle_detected:
            self.get_logger().warn('[Main Brain] 라이다 차단: 전방 장애물 발견! 차량 즉시 정지 후 차선 회피 돌입.')
            self.publish_motor_command('STOP')
            self.plan_lane_change()
        else:
            # 주행 방해 요소가 없다면 평상시 밸런싱 모드로 전진 명령 발행
            self.publish_motor_command('FORWARD')

    def plan_lane_change(self):
        """ 차선 변경을 시작하기 전 방향 및 목표 상태를 지정하는 플래너 """
        if self.current_lane == 1:
            self.get_logger().info('[Planner] 1차선 -> 2차선으로 회피 궤적 시퀀스를 시작합니다.')
            self.target_lane = 2
            self.turn_direction = -1.0 # 제자리 우회전 방향 지정
        else:
            self.get_logger().info('[Planner] 2차선 -> 1차선으로 회피 궤적 시퀀스를 시작합니다.')
            self.target_lane = 1
            self.turn_direction = 1.0  # 제자리 좌회전 방향 지정
            
        self.is_changing_lane = True
        self.lane_change_step = 1
        self.step_timer = 0

    def execute_lane_change_sequence(self):
        """ 타이머 카운팅 기반 주행 궤적 강제 제어 오토마타 시퀀스 """
        self.step_timer += 1
        motor_mode = 'STOP'
        
        # [Step 1] 차체 각도를 대각선으로 틀어주는 제자리 회전 단계 (Pivot Turn)
        if self.lane_change_step == 1:
            motor_mode = 'PIVOT_RIGHT' if self.turn_direction == -1.0 else 'PIVOT_LEFT'
            if self.step_timer > 30: # 현장 모터 파워에 맞게 타이밍 가감 튜닝
                self.lane_change_step = 2
                self.step_timer = 0
                
        # [Step 2] 옆 차선으로 파고드는 대각선 전진 주행 단계
        elif self.lane_change_step == 2:
            motor_mode = 'FORWARD'
            if self.step_timer > 50: # 복귀 시작 시점 타이밍 조율 범위
                self.lane_change_step = 3
                self.step_timer = 0
                
        # [Step 3] 진입한 차선 도로 방향과 평행하게 차체를 다시 정렬하는 역방향 제자리 회전 단계
        elif self.lane_change_step == 3:
            motor_mode = 'PIVOT_LEFT' if self.turn_direction == -1.0 else 'PIVOT_RIGHT'
            if self.step_timer > 30:
                self.lane_change_step = 4
                self.step_timer = 0
                
        # [Step 4] 차선 변경 완료 처리 및 평시 주행 상태 복귀 유도 단계
        elif self.lane_change_step == 4:
            self.current_lane = self.target_lane
            self.is_changing_lane = False
            self.get_logger().info(f'[Planner] 차선 변경 완료! 현재 위치: {self.current_lane}차선')
            motor_mode = 'FORWARD'

        self.publish_motor_command(motor_mode)

    def publish_motor_command(self, mode):
        """ [구 motor_driver_node 핵심 이식] 유저 전용 물리 속도 밸런스를 적용하여 하드웨어 제어 토픽 발행 """
        twist = Twist()
        
        if mode == 'FORWARD':
            self.get_logger().info(f'[Engine] 직진 주행구동 -> 고정 보정 출력 [L: {self.LEFT_PWM_BALANCED} / R: {self.RIGHT_PWM_BALANCED}]')
            twist.linear.x = self.BASE_FORWARD_SPEED
            twist.angular.z = 0.0
            
        elif mode == 'PIVOT_LEFT':
            # 반대 바퀴가 역회전하여 제자리 회전이 수행되도록 부호 보정 처리
            self.get_logger().info(f'[Engine] 제자리 좌회전 -> 좌우 카운터 출력 [L: {self.LEFT_PWM_BALANCED} / R: {self.RIGHT_PWM_BALANCED}]')
            twist.linear.x = 0.0
            twist.angular.z = self.PIVOT_TURN_SPEED
            
        elif mode == 'PIVOT_RIGHT':
            # 반대 바퀴가 역회전하여 제자리 회전이 수행되도록 부호 보정 처리
            self.get_logger().info(f'[Engine] 제자리 우회전 -> 좌우 카운터 출력 [L: {self.LEFT_PWM_BALANCED} / R: {self.RIGHT_PWM_BALANCED}]')
            twist.linear.x = 0.0
            twist.angular.z = -self.PIVOT_TURN_SPEED
            
        elif mode == 'STOP':
            self.get_logger().info('[Engine] 하드웨어 브레이크 정지 -> 출력 락 [L: 0 / R: 0]')
            twist.linear.x = 0.0
            twist.angular.z = 0.0
            
        self.cmd_pub.publish(twist)

def main(args=None):
    rclpy.init(args=args)
    node = CentralMainController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
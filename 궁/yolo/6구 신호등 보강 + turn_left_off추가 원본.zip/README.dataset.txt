# best_s_model > 6구 신호등 보강 + turn_left_off 추가 + 데이터 증강 원본
https://universe.roboflow.com/krocksians-workspace/best_s_model

Provided by a Roboflow user
License: CC BY 4.0


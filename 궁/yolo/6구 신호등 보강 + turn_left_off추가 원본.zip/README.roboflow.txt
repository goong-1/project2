
best_s_model - v6 6구 신호등 보강 + turn_left_off 추가 + 데이터 증강 원본
==============================

This dataset was exported via roboflow.com on June 4, 2026 at 3:02 AM GMT

Roboflow is an end-to-end computer vision platform that helps you
* collaborate with your team on computer vision projects
* collect & organize images
* understand and search unstructured image data
* annotate, and create datasets
* export, train, and deploy computer vision models
* use active learning to improve your dataset over time

For state of the art Computer Vision training notebooks you can use with this dataset,
visit https://github.com/roboflow/notebooks

To find over 100k other datasets and pre-trained models, visit https://universe.roboflow.com

The dataset includes 695 images.
Final-P7MD-U0M0-5liT are annotated in YOLOv8 format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 640x480 (Stretch)

No image augmentation techniques were applied.



import os
from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration

def generate_launch_description():
    return LaunchDescription([
        # 1. 런치 인자(Arguments) 선언
        DeclareLaunchArgument(name='product_name', default_value='LDLiDAR_LD19'),
        DeclareLaunchArgument(name='topic_name', default_value='scan'),
        DeclareLaunchArgument(name='port_name', default_value='/dev/ttyUSB0'),
        DeclareLaunchArgument(name='port_baudrate', default_value='230400'),
        DeclareLaunchArgument(name='frame_id', default_value='laser_frame'),

        # 2. ldlidar_stl_ros2 노드 구동 정의
        Node(
            package='ldlidar_stl_ros2',
            executable='ldlidar_stl_ros2_node',
            name='ldlidar_stl_ros2_node',
            output='screen',
            parameters=[
                {'product_name': LaunchConfiguration('product_name')},
                {'topic_name': LaunchConfiguration('topic_name')},
                {'port_name': LaunchConfiguration('port_name')},
                {'port_baudrate': LaunchConfiguration('port_baudrate')},
                {'frame_id': LaunchConfiguration('frame_id')}
            ],
            # 핵심 조치: 노드 내부 네임스페이스에 갇힌 토픽을 글로벌 루트(/scan)로 강제 추출
            remappings=[
                ('ldlidar_stl_ros2_node/scan', '/scan'),
                ('~/scan', '/scan')
            ]
        )
    ])

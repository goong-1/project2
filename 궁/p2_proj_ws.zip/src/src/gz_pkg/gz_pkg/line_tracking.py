import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
from cv_bridge import CvBridge
import cv2
import numpy as np
import time

class LaneFollower(Node):
    def __init__(self):
        super().__init__('lane_follower')
        self.image_sub = self.create_subscription(
            Image, '/camera/image_raw', self.image_callback, qos_profile_sensor_data)
        self.publisher = self.create_publisher(Twist, '/cmd_vel', 10)
        self.bridge = CvBridge()

        # 주행 및 FSM 제어 변수
        self.lane_width = 350
        self.state = "CRUISE"
        self.avoid_direction = 0

        # 빨간 정지선 관련 변수
        self.stop_start_time = 0.0
        self.red_line_latched = False

        # 회색 장애물 관련 변수 (타이머 없음, 비전 기반 탈출)
        self.obstacle_latched = False

        # 속도 설정
        self.cruise_speed = 1.5
        self.avoid_speed = 1.0

    def image_callback(self, msg):
        cv_image = self.bridge.imgmsg_to_cv2(msg, "bgr8")
        height, width, _ = cv_image.shape
        roi = cv_image[int(height/2):height, 0:width]
        hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)

        # 1. 마스킹 생성
        # 차선 마스크 (노란색 + 검은색)
        mask_yellow = cv2.inRange(hsv, np.array([20, 100, 100]), np.array([40, 255, 255]))
        mask_black = cv2.inRange(hsv, np.array([0, 0, 0]), np.array([180, 255, 50]))
        combined_mask = cv2.bitwise_or(mask_yellow, mask_black)

        # 회색 장애물 마스크
        mask_gray = cv2.inRange(hsv, np.array([0, 0, 50]), np.array([180, 50, 180]))

        # 빨간 정지선 마스크
        mask_red = cv2.bitwise_or(
            cv2.inRange(hsv, np.array([0, 120, 70]), np.array([10, 255, 255])),
            cv2.inRange(hsv, np.array([170, 120, 70]), np.array([180, 255, 255]))
        )

        # 2. 차선 중심 검출 (화면을 좌/우 50%로 분할)
        left_mask = combined_mask[:, :width//2]
        right_mask = combined_mask[:, width//2:]
        m_left = cv2.moments(left_mask)
        m_right = cv2.moments(right_mask)
        cx_left = int(m_left['m10'] / m_left['m00']) if m_left['m00'] > 0 else -1
        cx_right = int(m_right['m10'] / m_right['m00']) + (width//2) if m_right['m00'] > 0 else -1
        if cx_left != -1 and cx_right != -1: self.lane_width = cx_right - cx_left

        # 3. 비전 기반 장애물 정밀 분석 (위치 추적)
        contours, _ = cv2.findContours(mask_gray, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        valid_contours = [cnt for cnt in contours if cv2.contourArea(cnt) > 1000]

        obstacle_detected = len(valid_contours) > 0
        obstacle_in_front = False
        obj_cx = -1

        if obstacle_detected:
            largest_cnt = max(valid_contours, key=cv2.contourArea)
            M = cv2.moments(largest_cnt)
            if M['m00'] > 0:
                obj_cx = int(M['m10'] / M['m00'])
                # 장애물이 화면 중앙(가로 30% ~ 70%)에 있는지 확인
                if int(width * 0.3) <= obj_cx <= int(width * 0.7):
                    obstacle_in_front = True

        # 빨간 정지선 판단
        red_line_detected = cv2.countNonZero(mask_red) > 5000

        # 4. [래치 해제 제어] 화면에서 완전히 사라지면 리셋
        if not red_line_detected:
            self.red_line_latched = False
        if not obstacle_detected:
            self.obstacle_latched = False

        # 5. 유한 상태 머신 (FSM) 업데이트
        current_time = time.time()

        if self.state == "STOP_TIMER":
            if current_time - self.stop_start_time > 3.0:
                self.state = "CRUISE"

        elif self.state == "AVOID":
            if obj_cx != -1:
                # 장애물이 화면 양끝 구석(25% 미만, 또는 75% 초과)으로 치워졌으면 회피 완료
                if (self.avoid_direction == 1 and obj_cx < int(width * 0.25)) or \
                   (self.avoid_direction == -1 and obj_cx > int(width * 0.75)):
                    self.state = "CRUISE"
                    self.obstacle_latched = True
            else:
                self.state = "CRUISE"
                self.obstacle_latched = True

        if self.state == "CRUISE":
            if red_line_detected and not self.red_line_latched:
                self.state = "STOP_TIMER"
                self.stop_start_time = current_time
                self.red_line_latched = True
            elif obstacle_in_front and not self.obstacle_latched:
                self.state = "AVOID"
                left_val = cv2.countNonZero(mask_yellow[:, :width//2])
                right_val = cv2.countNonZero(mask_yellow[:, width//2:])
                self.avoid_direction = 1 if left_val > right_val else -1

        # 6. 제어 명령 발행
        twist = Twist()
        target_x = width // 2

        if self.state == "STOP_TIMER":
            pass # 속도 0 정지
        elif self.state == "AVOID":
            twist.linear.x = self.avoid_speed
            target_x = (width // 2) + (self.avoid_direction * int(self.lane_width * 0.8))
        else: # CRUISE
            twist.linear.x = self.cruise_speed
            if cx_left != -1 and cx_right != -1: target_x = (cx_left + cx_right) // 2
            elif cx_left != -1: target_x = cx_left + (self.lane_width // 2)
            elif cx_right != -1: target_x = cx_right - (self.lane_width // 2)

        twist.angular.z = float((width / 2) - target_x) * 0.007
        self.publisher.publish(twist)

        # 7. 디버깅 화면 구성 (차선 및 장애물 동시 확인)
        debug_img = roi.copy()

        # [디버깅 창 1, 2] 마스크 이미지 직접 확인
        cv2.imshow("Debug: Lane Mask (Yellow+Black)", combined_mask)
        cv2.imshow("Debug: Gray Obstacle Mask", mask_gray)

        # 좌/우 차선 중심점 (초록색 점)
        if cx_left != -1:
            cv2.circle(debug_img, (cx_left, int(height/4)), 10, (0, 255, 0), -1)
        if cx_right != -1:
            cv2.circle(debug_img, (cx_right, int(height/4)), 10, (0, 255, 0), -1)

        # 목표 조향 지점 (빨간색 점)
        cv2.circle(debug_img, (target_x, int(height/4)), 15, (0, 0, 255), -1)

        # 장애물 중심점 (정면: 주황색, 측면 회피 중: 하늘색 점)
        if obj_cx != -1:
            color = (0, 165, 255) if obstacle_in_front else (255, 191, 0)
            cv2.circle(debug_img, (obj_cx, int(height/4)), 10, color, -1)

        # 상태 텍스트
        status_text = f"State: {self.state} | ObsLatched: {self.obstacle_latched}"
        cv2.putText(debug_img, status_text, (10, 30), 1, 1, (255, 255, 255), 2)

        # [디버깅 창 3] 종합 비전 제어 뷰
        cv2.imshow("Vision Control Debug View", debug_img)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            self.destroy_node()
            rclpy.shutdown()

def main(args=None):
    rclpy.init(args=args)
    node = LaneFollower()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

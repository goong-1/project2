import rclpy

from rclpy.node import Node

from std_msgs.msg import Float64

import sys

import select

import termios

import tty

import threading



class IntegratedController(Node):

    def __init__(self):

        super().__init__('integrated_controller')



        self.tl_pub = self.create_publisher(Float64, '/traffic_light/cmd_pos', 10)

        self.tl_timer = self.create_timer(7.0, self.tl_timer_callback)

        self.is_red_showing = True



        self.obs_pub = self.create_publisher(Float64, '/obstacle/cmd_vel', 10)

        self.is_at_origin = True

        self.velocity = 10.0

        self.move_duration = 3.0



        # 타이머 객체 변수 초기화

        self.stop_timer = None



        self.settings = termios.tcgetattr(sys.stdin)

        self.keyboard_thread = threading.Thread(target=self.keyboard_loop)

        self.keyboard_thread.daemon = True

        self.keyboard_thread.start()



    def tl_timer_callback(self):

        msg = Float64()

        if self.is_red_showing:

            msg.data = -0.015

        else:

            msg.data = 0.015

        self.tl_pub.publish(msg)

        self.is_red_showing = not self.is_red_showing



    def stop_obstacle(self):

        msg = Float64()

        msg.data = 0.0

        self.obs_pub.publish(msg)

        # 타이머가 한 번 실행되면 파괴

        if self.stop_timer:

            self.destroy_timer(self.stop_timer)

            self.stop_timer = None

        self.get_logger().info("[장애물] 이동 완료 및 정지")



    def get_key(self):

        try:

            tty.setcbreak(sys.stdin.fileno())

            rlist, _, _ = select.select([sys.stdin], [], [], 0.1)

            if rlist:

                return sys.stdin.read(1)

        finally:

            # 설정 복구

            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.settings)

        return ''



    def keyboard_loop(self):

        try:

            while rclpy.ok():

                key = self.get_key()

                if key == 'm' or key == 'M':

                    msg = Float64()

                    if self.is_at_origin:

                        msg.data = -self.velocity

                        self.is_at_origin = False

                    else:

                        msg.data = self.velocity

                        self.is_at_origin = True



                    self.obs_pub.publish(msg)

                    # 이전 타이머가 있다면 취소

                    if self.stop_timer:

                        self.destroy_timer(self.stop_timer)

                    # 새 타이머 설정

                    self.stop_timer = self.create_timer(self.move_duration, self.stop_obstacle)

                elif key == '\x03':

                    break

        except Exception as e:

            self.get_logger().error(f"Error: {e}")

        finally:

            # 스레드 종료 시에도 터미널 설정 복구 보장

            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.settings)



def main(args=None):

    rclpy.init(args=args)

    node = IntegratedController()

    try:

        rclpy.spin(node)

    except KeyboardInterrupt:

        pass

    finally:

        # 종료 직전 터미널 설정 강제 복구

        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, node.settings)

        node.destroy_node()

        rclpy.shutdown()



if __name__ == '__main__':

    main()

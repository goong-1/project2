#include <Arduino.h>
#include <cmath>
#include "IMU.h"
#include "soc/soc.h"
#include "soc/rtc_cntl_reg.h"

// ==========================================
// [핀 맵 설정] (모터 및 엔코더 핀 - UART와 충돌 없음)
// ==========================================
const uint16_t PWMA = 26; const uint16_t AIN1 = 22; const uint16_t AIN2 = 23;
const uint16_t PWMB = 25; const uint16_t BIN1 = 21; const uint16_t BIN2 = 17;
const uint16_t AENCA = 35; const uint16_t AENCB = 34;
const uint16_t BENCA = 27; const uint16_t BENCB = 16;

// ==========================================
// [엔코더 카운트 전역 변수]
// ==========================================
volatile long A_wheel_pulse_count = 0;
volatile long B_wheel_pulse_count = 0;
volatile int current_dir_A = 1;
volatile int current_dir_B = 1;

void IRAM_ATTR A_wheel_pulse() { A_wheel_pulse_count += current_dir_A; }
void IRAM_ATTR B_wheel_pulse() { B_wheel_pulse_count += current_dir_B; }

// ==========================================
// [물리 가중치 및 제어 게인 설정]
// ==========================================
const float MOTOR_A_WEIGHT = 1.01;
const float MOTOR_B_WEIGHT = 1.00;
const float HEADING_KP = 1.2;
const int TURN_SPEED = 85;

// ==========================================
// [제어 상태 및 센서 변수]
// ==========================================
enum RobotState { IDLE, DRIVE_STRAIGHT, TURN };
RobotState currentState = IDLE;

EulerAngles stAngles;
IMU_ST_SENSOR_DATA_FLOAT stGyroRawData, stAccelRawData;
IMU_ST_SENSOR_DATA stMagnRawData;

float target_yaw = 0.0;
float current_yaw = 0.0;
float gyro_z_offset = 0.0;
float gyro_accumulated_deg = 0.0;
float target_turn_angle = 0.0;

int current_speed = 0; // 라즈베리파이로부터 명령받은 가변 주행 속도 저장
String cmd_buffer = "";

// 🚨 통신 차단 안전 감시용 타임스탬프
unsigned long last_communication_time = 0;
const unsigned long SAFETY_TIMEOUT_MS = 2000; // 통신 두절 허용 시간 (2초 = 2000ms)

// ==========================================
// [모터 액추에이팅 제어 함수]
// ==========================================
void controlMotor(char motor, int speed) {
  uint16_t pwm_pin, in1_pin, in2_pin;
  float weight = 1.0;
  if (motor == 'A') {
    pwm_pin = PWMA; in1_pin = AIN1; in2_pin = AIN2; weight = MOTOR_A_WEIGHT;
  } else {
    pwm_pin = PWMB; in1_pin = BIN1; in2_pin = BIN2; weight = MOTOR_B_WEIGHT;
  }

  int final_speed = constrain((int)(speed * weight), -255, 255);

  if (final_speed > 0) {
    digitalWrite(in1_pin, HIGH); digitalWrite(in2_pin, LOW);
    ledcWrite(pwm_pin, final_speed);
  } else if (final_speed < 0) {
    digitalWrite(in1_pin, LOW); digitalWrite(in2_pin, HIGH);
    ledcWrite(pwm_pin, abs(final_speed));
  } else {
    digitalWrite(in1_pin, LOW); digitalWrite(in2_pin, LOW);
    ledcWrite(pwm_pin, 0);
  }
}

// ==========================================
// [자이로스코프 영점 교정]
// ==========================================
void calibrateGyro() {
  float sum = 0;
  int samples = 500;
  for (int i = 0; i < samples; i++) {
    imuDataGet(&stAngles, &stGyroRawData, &stAccelRawData, &stMagnRawData);
    sum += stGyroRawData.Z;
    delay(2);
  }
  gyro_z_offset = sum / samples;
}

// ==========================================
// [초기 설정]
// ==========================================
void setup() {
  WRITE_PERI_REG(RTC_CNTL_BROWN_OUT_REG, 0); // 브라운아웃 리셋 방지
  
  // 라즈베리파이와 직결되는 기본 하드웨어 시리얼 개방
  Serial.begin(115200); 

  pinMode(AIN1, OUTPUT); pinMode(AIN2, OUTPUT);
  pinMode(BIN1, OUTPUT); pinMode(BIN2, OUTPUT);
  pinMode(AENCA, INPUT); pinMode(AENCB, INPUT);
  pinMode(BENCA, INPUT); pinMode(BENCB, INPUT);
  attachInterrupt(digitalPinToInterrupt(AENCA), A_wheel_pulse, RISING);
  attachInterrupt(digitalPinToInterrupt(BENCA), B_wheel_pulse, RISING);

  ledcAttach(PWMA, 20000, 8);
  ledcAttach(PWMB, 20000, 8);
  
  imuInit();
  delay(500);
  calibrateGyro();

  last_communication_time = millis();
}

// ==========================================
// [메인 제어 루프]
// ==========================================
void loop() {
  // 자이로 누적 적분을 위한 마이크로초 기반 정밀 시간 변화량 계산
  static unsigned long last_loop_time = 0;
  unsigned long now = micros();
  if (last_loop_time == 0) last_loop_time = now;
  float dt = (now - last_loop_time) / 1000000.0;
  last_loop_time = now;

  imuDataGet(&stAngles, &stGyroRawData, &stAccelRawData, &stMagnRawData);
  float gyro_z_deg_per_sec = (stGyroRawData.Z - gyro_z_offset);

  // 1. 명령어 패킷 스트림 분석 (라즈베리파이 시리얼 통신)
  while (Serial.available() > 0) {
    char c = Serial.read();
    
    // 명령 패킷의 조각이라도 들어오면 타임스탬프 갱신 (생존 신고)
    last_communication_time = millis(); 

    if (c == '<') {
      cmd_buffer = "";
    } else if (c == '>') {
      // [명령 1] 즉시 정지 명령
      if (cmd_buffer == "s") {
        currentState = IDLE;
        controlMotor('A', 0); controlMotor('B', 0);
      } 
      // [명령 2] 가변 속도 직진 명령 (예: <g,150>)
      else if (cmd_buffer.startsWith("g,")) {
        current_speed = cmd_buffer.substring(2).toInt();
        target_yaw = current_yaw; // 수신 순간의 기수를 락온
        currentState = DRIVE_STRAIGHT;
      } 
      // [명령 3] 정밀 회전 명령 (예: <t,-90>)
      else if (cmd_buffer.startsWith("t,")) {
        target_turn_angle = cmd_buffer.substring(2).toFloat();
        gyro_accumulated_deg = 0.0; // 회전 시작 시 누적 각도 리셋
        currentState = TURN;
      }
      cmd_buffer = ""; // 처리 후 버퍼 비우기
    } else {
      cmd_buffer += c;
    }
  }

  // 2. 🚨 통신 두절 세이프가드 (2초 초과 시 긴급 제동)
  if (millis() - last_communication_time > SAFETY_TIMEOUT_MS) {
    if (currentState != IDLE) {
      controlMotor('A', 0); controlMotor('B', 0);
      currentState = IDLE;
    }
  }

  // 3. 주행 상태 머신 및 PID 보정 액추에이팅
  if (currentState == DRIVE_STRAIGHT) {
    current_yaw += (gyro_z_deg_per_sec * dt); 
    
    float error = target_yaw - current_yaw;
    while (error > 180.0) error -= 360.0;
    while (error <= -180.0) error += 360.0;
    
    int correction = constrain((int)(error * HEADING_KP), -40, 40);
    int speed_A = constrain(current_speed + correction, 0, 255);
    int speed_B = constrain(current_speed - correction, 0, 255);
    
    controlMotor('A', speed_A); controlMotor('B', speed_B);
  } 
  else if (currentState == TURN) {
    if (abs(gyro_z_deg_per_sec) > 0.1) {
      gyro_accumulated_deg += (gyro_z_deg_per_sec * dt);
    }
    
    if (abs(gyro_accumulated_deg) >= abs(target_turn_angle)) {
      controlMotor('A', 0); controlMotor('B', 0);
      currentState = IDLE;
    } else {
      if (target_turn_angle > 0) { 
        controlMotor('A', -TURN_SPEED); controlMotor('B', TURN_SPEED);
      } else { 
        controlMotor('A', TURN_SPEED);  controlMotor('B', -TURN_SPEED);
      }
    }
  }

  // 4. 라즈베리파이로 상태 피드백 전송 (50ms 주기)
  // 파이썬 측에서 이 데이터를 읽어 현재 주행 상황을 인지할 수 있습니다.
  static unsigned long last_send_time = 0;
  if (millis() - last_send_time >= 50) {
    last_send_time = millis();
    Serial.print("MODE: ");
    if(currentState == IDLE) Serial.print("IDLE");
    else if(currentState == DRIVE_STRAIGHT) Serial.print("DRIVE");
    else if(currentState == TURN) Serial.print("TURN");

    Serial.print(" | Yaw: "); Serial.print(current_yaw);
    Serial.print(" | TurnAng: "); Serial.println(gyro_accumulated_deg);
  }

  delay(1); 
}
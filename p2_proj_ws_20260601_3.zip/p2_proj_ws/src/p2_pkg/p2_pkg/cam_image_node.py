#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image, CompressedImage  
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
import cv2
from cv_bridge import CvBridge
import time

class CameraPublisherNode(Node):
    def __init__(self):
        super().__init__('camera_publisher_node')

        # [QoS 최적화] 무선 와이파이 환경에서 병목 및 레이턴시를 줄이기 위해 BEST_EFFORT 적용
        qos_profile = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )
        
        # 원본 이미지 발행자 및 압축 이미지 발행자 선언
        self.publisher_ = self.create_publisher(Image, 'image_raw', qos_profile)
        self.compressed_publisher_ = self.create_publisher(CompressedImage, 'image_raw/compressed', qos_profile)
        
        self.br = CvBridge()
        DEVICE_ID = 0
        self.cap = cv2.VideoCapture(DEVICE_ID, cv2.CAP_V4L2)
        
        time.sleep(0.5)

        # [Wi-Fi 대역폭 맞춤형 하드웨어 제한 세팅 - 640x480 변경 및 효율화]
        self.cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        self.cap.set(cv2.CAP_PROP_FPS, 15)
        self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1) # 버퍼 크기를 최소화하여 영상 밀림(레이턴시) 방지

        if not self.cap.isOpened():
            self.get_logger().error('Ubuntu V4L2: 하드웨어 카메라 장치를 열 수 없습니다!')
            return

        self.timer = self.create_timer(1.0 / 15.0, self.timer_callback)
        self.get_logger().info('카메라 하드웨어 리퍼블리셔 노드가 와이파이 최적화 모드로 가동되었습니다. (640x480)')

    def timer_callback(self):
        ret, frame = self.cap.read()
        
        if ret and frame is not None:
            if frame.shape[1] != 640 or frame.shape[0] != 480:
                frame = cv2.resize(frame, (640, 480))

            # [1] Raw 원본 이미지 토픽 발행
            msg = self.br.cv2_to_imgmsg(frame, encoding="bgr8")
            self.publisher_.publish(msg)
            
            # [2] Compressed 압축 이미지 토픽 발행 (와이파이 전송용 필수)
            comp_msg = CompressedImage()
            comp_msg.header = msg.header
            comp_msg.format = "jpeg"
            
            # 640x480 해상도 증가에 따라 용량 효율화를 위해 화질 계수를 65로 최적화 조정
            _, compressed_img = cv2.imencode('.jpg', frame, [int(cv2.IMWRITE_JPEG_QUALITY), 65])
            comp_msg.data = compressed_img.tobytes()
            
            self.compressed_publisher_.publish(comp_msg)
        else:
            self.get_logger().warn('카메라 장치로부터 비디오 프레임을 가져오지 못했습니다.')

def main(args=None):
    rclpy.init(args=args)
    node = CameraPublisherNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if node.cap.isOpened():
            node.cap.release()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
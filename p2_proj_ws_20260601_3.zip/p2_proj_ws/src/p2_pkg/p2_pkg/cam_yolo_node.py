#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import CompressedImage  
from std_msgs.msg import String  
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
import cv2
import numpy as np
import json
from pathlib import Path
import os

os.environ['ROS_DOMAIN_ID'] = '30'
from p2_pkg.sign_detector import TrafficSignDetector

class CameraParserNode(Node):
    def __init__(self):
        super().__init__('camera_parser_node')

        self.SHOW_DISPLAY = False 
        BASE_DIR = Path(__file__).resolve().parent
        MODEL_PATH = BASE_DIR / "best.pt"

        self.detector = TrafficSignDetector(
            model_path=str(MODEL_PATH),
            conf_threshold=0.70
        )

        image_qos_profile = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=5
        )

        self.image_sub = self.create_subscription(
            CompressedImage,
            'image_raw/compressed',
            self.image_callback,
            image_qos_profile
        )

        self.result_pub = self.create_publisher(String, 'traffic_sign_topic', 10)

        self.yolo_image_pub = self.create_publisher(
            CompressedImage, 
            'image_yolo/compressed', 
            image_qos_profile
        )

        self.last_print_time = self.get_clock().now()
        self.get_logger().info('==================================================')
        self.get_logger().info(' YOLO 압축 수신 및 결과 화면 노트북 송신 노드 가동 ')
        self.get_logger().info('==================================================')
        
        self.valid_actions = {"STOP", "GO", "SPEED_LIMIT", "TURN_LEFT"}
        self.roi_ratio = (0.10, 0.01, 0.90, 0.50)
        self.min_area_ratio = 0.010
        self.last_sent_action = None
        self.no_detection_count = 0
        self.reset_after_missing_frames = 10
        
    def image_callback(self, msg):
        try:
            frame = cv2.imdecode(np.frombuffer(msg.data, np.uint8), cv2.IMREAD_COLOR)
        except Exception as e:
            self.get_logger().error(f'압축 이미지 디코딩 변환 실패: {str(e)}')
            return

        if frame is None:
            return

        all_detections = self.detector.detect_all(frame)
        detections = self.filter_detections_by_roi(all_detections, frame)

        if not detections:
            self.no_detection_count += 1
            if self.no_detection_count >= self.reset_after_missing_frames:
                self.last_sent_action = None

            debug_frame = self.detector.draw_all(frame, detections)
            x1, y1, x2, y2 = self.get_roi_box(frame)
            cv2.rectangle(debug_frame, (x1, y1), (x2, y2), (255, 0, 0), 2)
            cv2.putText(debug_frame, "NO VALID DETECTION", (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
            
            self.publish_yolo_frame(debug_frame, msg.header)
            return

        self.no_detection_count = 0
        main_action = self.detector.get_main_action(detections)
        action_hint = main_action.get("action_hint", None)

        if action_hint not in self.valid_actions:
            return

        if action_hint == self.last_sent_action:
            debug_frame = self.detector.draw_all(frame, detections)
            x1, y1, x2, y2 = self.get_roi_box(frame)
            cv2.rectangle(debug_frame, (x1, y1), (x2, y2), (255, 0, 0), 2)
            cv2.putText(debug_frame, f"ALREADY SENT: {action_hint}", (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
            
            self.publish_yolo_frame(debug_frame, msg.header)
            return

        string_msg = String()
        string_msg.data = action_hint
        self.result_pub.publish(string_msg)
        self.last_sent_action = action_hint
        
        debug_frame = self.detector.draw_all(frame, detections)
        x1, y1, x2, y2 = self.get_roi_box(frame)
        cv2.rectangle(debug_frame, (x1, y1), (x2, y2), (255, 0, 0), 2)
        cv2.putText(debug_frame, f"SENT: {action_hint}", (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
        
        self.publish_yolo_frame(debug_frame, msg.header)

        current_time = self.get_clock().now()
        elapsed_time = (current_time - self.last_print_time).nanoseconds / 1e9
        if elapsed_time > 0.5:
            self.get_logger().info(f'[YOLO AI Result] FINAL ACTION HINT -> {action_hint}')
            self.last_print_time = current_time

    # ★ [수정] 640x480 데이터 증가량 억제를 위해 품질 계수를 70으로 최적화 다운 전송
    def publish_yolo_frame(self, debug_frame, header):
        if debug_frame is not None:
            yolo_comp_msg = CompressedImage()
            yolo_comp_msg.header = header  
            yolo_comp_msg.format = "jpeg"
            
            # 해상도 640x480 팽창 대응 효율 제어
            _, encoded_img = cv2.imencode('.jpg', debug_frame, [int(cv2.IMWRITE_JPEG_QUALITY), 70])
            yolo_comp_msg.data = encoded_img.tobytes()
            
            self.yolo_image_pub.publish(yolo_comp_msg)
            
    def get_roi_box(self, frame):
        h, w = frame.shape[:2]
        rx1, ry1, rx2, ry2 = self.roi_ratio
        return int(w * rx1), int(h * ry1), int(w * rx2), int(h * ry2)

    def filter_detections_by_roi(self, detections, frame):
        roi_x1, roi_y1, roi_x2, roi_y2 = self.get_roi_box(frame)
        filtered = []
        for d in detections:
            try:
                act = d.action_hint
                area = d.area_ratio
                cx = d.center["x"]
                cy = d.center["y"]
            except AttributeError:
                act = d.get("action_hint")
                area = d.get("area_ratio")
                cx = d.get("center", {}).get("x", 0)
                cy = d.get("center", {}).get("y", 0)

            if act not in self.valid_actions or not (roi_x1 <= cx <= roi_x2 and roi_y1 <= cy <= roi_y2) or area < self.min_area_ratio:
                continue
            filtered.append(d)
        return filtered
    
def main(args=None):
    rclpy.init(args=args)
    node = CameraParserNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()